﻿model Number{
	public
	__decl{
		num value;
		string type;
	}
	
	__func(value){}
}

_stop_
