﻿model String{
	__decl{
		string value;
		function size(){
			return 34;
		}
	}
	
	__func(value){}
}

_stop_
