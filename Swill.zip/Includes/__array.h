﻿model Array{
	__exec{
		println("This is the array model");
	}
}

_stop_
