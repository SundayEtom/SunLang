﻿#include <iostream>
#include "parser.hpp"

int main(int argc, char *argv[]){
	Parser parser("test.c");
	
	return 0;
}
