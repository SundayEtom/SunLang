﻿#ifndef PARSER_HPP
#define PARSER_HPP

#include "scanner.hpp"
#include "value.hpp"
#include "symbol.hpp"
#include "environment.hpp"
#include "utils.hpp"



class Parser{
	private:
	Scanner sc;
	Symbol latest_symbol;
	Tokens latest_operation;
	bool declare_public;	// true if symbols have public access, false otherwise.
	
	
	public:
	// Constructor: To initialize the scanner and parse the program
	Parser(string text_or_file);
	 
	private:
	//Save current token as previous and get a new one.
	bool advance();
	
	// See which token is next, without actually
	// altering current parser state.
	Tokens lookahead();
	
	// Compare current token to the expected one
	bool match(Tokens tok);
	
	// Compare current lexeme to the expected one
	bool match(string lex);
	
	// Print error message and stop the parser. exit() is included in scanner (cstdlib)
	void terminate(string msg){
		print_error(msg);
		exit(EXIT_SUCCESS);
	}
	
	// Simply stop the parser, without error message
	void terminate(){ exit(EXIT_SUCCESS); }
	
	// Check if we're currently executing a model
	bool in_model();
	
	// Check if current lexeme is a type specifier
	bool is_typespec(string lex, Tokens& whichtok);
	
	// Check if current lexeme is a language keyword
	bool is_keyword(string lex);
	
	// Check if current lexeme is a symbol identifier
	bool is_identifier(string lex, bool decl);
	
	// If this is neither a keyword nor a symbol name, return true
	bool is_unknown(string lex, bool decl);
	
	// Is current token the name of a model?
	bool is_model(string lexeme);
	
	// Initialize an instance of a model
	void initialize_object(Symbol& sym);
	
	// Do the dirty work for initialize_object()
	Value initialize(int end);
	
	// Fetch and return the typespec token for the given lexeme
	Tokens get_typespec_tok(string lexeme);
	
	// Fetch and return the keyword token for the given lexeme
	Tokens get_keyword_tok(string lexeme);
	
	// Determine the specific assignment operation
	Tokens get_assignop_tok(string assignop);
	
	// Determine the specific arithmetic operation
	Tokens get_mathop_tok(string mathop);
	
	// What kind of comparison is being carried out?
	Tokens get_comparison_tok(string comptok);
	
	// Get the end of the current block
	int getblockend(bool dont_skip);
	
	// Save current parser state
	void save_parser_state();
	
	// Expression parser
	Value expression(bool fetch_next=true);
	
	// Parse a sub-expression called term
	Value term(bool fetch_next=true);
	
	
	// Restore parser state, and reset scanner if required.
	State restore_parser_state(bool reset_scanner);
	
	/*
	assert_unknown() checks that a name does not conflict
	with a keyword, type specifier or existing symbol.
	If this conflict is detected, an appropriate error
	message is printed and parsing is terminated.
	*/
	void assert_unknown(string lexeme, string used_for, bool decl);
	
	// Declare a new symbol. 'tok' is the type of this symbol
	string declaration(string class_name, Tokens tok);
	
	// Convert a number to string
	string numtostring(double num);
	
	// Increment a value by one
	Value increment(Symbol& sym);
	
	// Decrement a value by one
	Value decrement(Symbol& sym);
	
	// Assign the value of an expression to sym
	void assignment(Symbol& sym);
	
	// Print all comma-separated expressions until a closing bracket is found
	void print(string lexeme);
	
	// Evaluate an expression for boolean result (true | false)
	bool eval_bool(Value val);
	
	// Execute code until condition becomes false
	Value while_loop();
	
	// Execute block of code once if condition is true
	Value if_condition();
	
	// Invert the value of an expression
	Value invert();
	
	// Create a new model (or class, like in C++)
	bool class_decl(void);
	
	// Execute the body of a function
	Value execute_block_content(int end);
	
	// Execute object method
	Value function();
	
	// Execute a symbol's default function
	Value execute_object(int end);
	
	// Symbol evaluator, to assist factor
	Value evaluate(Symbol& sym);
	
	// Execute an object's __func function
	Value execute_object_ctor(string objname, bool is_symbol);
	
	/* 
	Any expression is a factor.
	In fact, every token is a factor which may or may not
	have a value. If a factor has no value, factor() returns
	an empty string.
	*/
	Value factor(bool fetch_next=true);
};



Parser::Parser(string text_or_file):
	sc{Scanner(text_or_file)},
	latest_symbol{Symbol("", "", Tokens::None)},
	declare_public{false}	// By default, all object members are private
{
	environment.newstackframe("environment");
	for(Source& src : sources){
		sc.switch_source(src.name);
		save_parser_state();
		advance();
		
		// Every program must start with a model declaration
		Tokens tok = get_typespec_tok(current.lexeme);
		
		if(tok == Tokens::Object_Model){
			while(tok == Tokens::Object_Model){
				if(!class_decl())	// class_decl() should advance after model declaration
					break;
				tok = get_typespec_tok(current.lexeme);
			}
		}
		else{
			terminate("Model declaration expected but found '"+current.lexeme+"' in file '"+src.name+"'.");
		}
		restore_parser_state(true);
	}
	
	
	
	/*
	After model declarations, we start the
	program execution here. Every complete program must have exactly one
	Start model, where program execution starts. If no model
	with name 'Start' is found, then we terminate with an error message.
	
	Observe that we copy the properties of model Start
	into the variable 'start', and pass the address of
	this variable to environment.newstackframe(). That way,
	we do not alter the actual Start model, otherwise, new
	instances of Start, if there be any, will share same
	values. This is the idea implemented in all model instances.
	*/
	
	Model start = environment.getmodel("Start");
	if(start.getname() == ""){
		terminate("No 'Start' model defined. Program stopped.");
	}
	else{
		// Search for and execute Start's executable blocks,
		// if it has any.
		environment.newstackframe(&start);
		active_models.push("Start");
		sc.setpos(start.getstart());
		advance();
		
		execute_object(start.getend());
		
		environment.popstack();
		active_models.pop();
	}
	// Uninstall the "environment" stack frame
	// and terminate the program.
	environment.popstack();
	terminate();			
}


bool Parser::in_model(){
	return active_models.in_model();
}



void Parser::save_parser_state(){
	State state(sc.getpos(), current, previous);
	parser_states.push(state);
}


State Parser::restore_parser_state(bool reset_scanner=true){
	State state = parser_states.pop();
	if(reset_scanner){
		sc.setpos(state.scannerpos);
		current = state.current;
		previous = state.previous;
	}
	return state;
}


bool Parser::match(Tokens tok){
	if(current.token == tok)
		return true;
	return false;
}



bool Parser::match(string lex){
	if(current.lexeme == lex)
		return true;
	return false;
}	



bool Parser::is_typespec(string lex, Tokens& whichtok){
	if(typespecs.count(lex) > 0){
		whichtok = typespecs.find(lex)->second;
		return true;
	}
	else if(environment.model_exists(lex)){
		whichtok = Tokens::Object;
		return true;
	}
	
	whichtok = Tokens::None;
	return false;
}


bool Parser::is_keyword(string lex){
	if(keywords.count(lex) > 0)
		return true;
	return false;
}


bool Parser::is_identifier(string lex, bool decl=true){
	return environment.symbol_exists(lex, decl);
}


void Parser::assert_unknown(string lexeme, string used_for, bool decl=true){
	string msg = "";
	Tokens tok;
	
	if(is_typespec(lexeme, tok))
		msg += "Use of a type specifier '"+lexeme+"' as "+used_for+".";
	else if(is_keyword(lexeme))
		msg += "Use of language keyword '"+lexeme+"' as "+used_for+".";
	else if(in_model() && is_identifier(lexeme, decl))
		msg += "Cannot redeclare '"+lexeme+"' as type '"+previous.lexeme+"'.";
	
	if(msg != "") terminate(msg);
}


bool Parser::is_unknown(string lex, bool decl=true){
	Tokens tok;
	if(!is_typespec(lex, tok) && 
		!is_keyword(lex) && 
		!is_identifier(lex, decl) &&
		!is_model(lex)
	)
		return true;
	return false;
}


bool Parser::is_model(string lexeme){
	if(models.count(lexeme) > 0)
		return true;
	return false;
}


Tokens Parser::get_typespec_tok(string lexeme){
	Tokens tok = Tokens::None;
	if(is_typespec(lexeme, tok)){
		return tok;
	}
	return Tokens::None;
}


Tokens Parser::get_comparison_tok(string comptok){
	if(comparison_ops.count(comptok) > 0){
		return comparison_ops.find(comptok)->second;
	}
	return Tokens::None;
}


Tokens Parser::get_keyword_tok(string lexeme){
	if(is_keyword(lexeme)){
		return keywords.find(lexeme)->second;
	}
	return Tokens::None;
}


Tokens Parser::get_assignop_tok(string assignop){
	if(assignops.count(assignop) > 0){
		return assignops.find(assignop)->second;
	}
	return Tokens::None;
}


Tokens Parser::get_mathop_tok(string mathop){
	if(mathops.count(mathop) > 0){
		return mathops.find(mathop)->second;
	}
	return Tokens::None;
}


// We assume the current token is Tokens::Obrace
// If dont_skip is true, the parser continues after the 
// block's end; else parsing continues at the block's
// beginning,which means the block is actually executed.
int Parser::getblockend(bool dont_skip=false){
	if(match(Tokens::Obrace)){
		// Save parser state
		save_parser_state();
		
		int obraces=1, cbraces=0;
		while(obraces != cbraces){
			advance();
			if(match(Tokens::Obrace)) obraces++;
			else if(match(Tokens::Cbrace)) cbraces++;
		}
		int blockend = sc.getpos();
		restore_parser_state(dont_skip);
		
		return blockend;
	}
	return -1;
}


	
bool Parser::advance(){
	previous = current;
	current.token  = sc.scan();
	if(match(Tokens::None)){
		terminate();
	}
	current.lexeme = sc.getlexeme();
	current.line_number = current_line;
	current.position = current_char-current.lexeme.length();
		
	return true;
}


Tokens Parser::lookahead(){
	save_parser_state();
	advance();
	Tokens tok = current.token;
	restore_parser_state();
	return tok;
}


// class_decl() simply creates a new type and adds it to usertypes
bool Parser::class_decl(void){
	advance();
	string model_name = current.lexeme;
	//cout << "class_decl(): Model name: '" << model_name << "'\n";
	
	if(match(Tokens::Cstring)){
		assert_unknown(model_name, "model object name");
		
		// Now move to model opening brace
		advance();
		
		Model model(model_name);
		model.setstart(sc.getpos());
		
		// true means 'don't skip the block'.
		// That means we're not yet done with this model
		// declaration. We're left with initilizing it, below.
		model.setend(getblockend(true));
		environment.newstackframe(&model);
		active_models.push(model_name);
		
		// Initialize the model by executing all declarations within it.
		// That way, we can use a symbol before its actual definition.
		save_parser_state();
		sc.setpos(model.getstart());
		advance();
		initialize(model.getend());
		
		// false means don't reset scanner.
		// That means we just pop last-saved parser state
		// from the stack without resetting the scanner to
		// its corresponding previous state. In other words,
		// we're done with and skipping this model block.
		restore_parser_state(false);
		
		environment.popstack();	// Pop this model's stack frame
		active_models.pop();
		environment.addmodel(model);
		
	}
	else{
		terminate("Model name must be a character string.");
	}
	return advance();
}


void Parser::initialize_object(Symbol& sym){
	/*
	Set up a new stack frame with a copy of the object model; 
	then after declaration, pop this stack
	frame and assign its address to the instance object's symbol stack.
	Next time we want to access this object's members, we'll simply
	install its symbol stack frame on the stack to access its last state.
	*/
	save_parser_state();
	Model mod = environment.getmodel(sym.getclassname());
				
	if(mod.getname() != ""){
		environment.newstackframe(&mod);
		sc.setpos(mod.getstart());
		//advance();
		
		initialize(mod.getend());
		environment.popstack();
					
		// Assign current model's stack frame to the symbol's symbol stack.
		*sym.symbol_stack = mod;
	}
	else{
		cout << "Model '" << sym.getclassname() << "' not found\n";
	}
	restore_parser_state();
}



Value Parser::initialize(int end){
	Value val;
	// Scan for declaration blocks and carry out
	// all declarations
	while(sc.getpos() != end){
		if(match("public") || match("private")){
			if(lookahead() == Tokens::Decl_Block){
				declare_public = (current.lexeme == "public")?true:false;
				advance();
			}
			//cout << "declare_public is now " << ((declare_public)?"public":"private") << endl;
		}
		
		if(match(Tokens::Decl_Block)){
			advance();	// This takes us to the opening brace of this block
			int end = getblockend(true);
			val = execute_block_content(end);
		}
		advance();
	}
	return val;
}



string Parser::declaration(string class_name, Tokens tok){
	advance();
	string symname = current.lexeme;
	//cout << "Declaring '" << symname << "' as " << class_name << " in " << active_models.get() << endl;
	
	switch(tok){
		case Tokens::Object:{
			assert_unknown(symname, "object name", true);
			
			// OK, symname does not exist in this scope, so create it.
			Symbol sym(symname, class_name, tok);
			sym.setaccess((declare_public)?"public":"private");
			
			// Initialize this symbol's stack
			sym.symbol_stack = new Model(sym.getname());
			*sym.symbol_stack = environment.getmodel(class_name);
			
			// Add new symbol to current stack;
			environment.addsymbol(sym);
			latest_symbol = sym;
			
			if(lookahead() == Tokens::Obrace){
				// Manual object construction
				advance();
				environment.newstackframe(sym.symbol_stack);
				execute_block_content(getblockend(true));
				environment.popstack();
			}
			else if(lookahead() == Tokens::Obracket){
				// Object construction through constructor (__ctor)
				execute_object_ctor(symname, true);
			}
		}break;
		
		
		case Tokens::Function:{
			//cout << "Declaring function: " << symname << endl;
			assert_unknown(symname, "function name", true);
			
			Symbol sym(symname, class_name, tok);
			sym.symbol_stack = new Model(symname);
			sym.setaccess((declare_public)?"public":"private");
			
			advance();
			if(match(Tokens::Obracket)){
				environment.newstackframe(sym.symbol_stack);
				advance();	// Step into the parameter list
				while(!match(Tokens::Cbracket)){
					Tokens type = get_typespec_tok(current.lexeme);
					if(type == Tokens::None){
						terminate("Unknown parameter type '"+current.lexeme+"'");
					}
					string name = declaration(current.lexeme, type);
					
					// Save this parameter name for later when
					// this function will be called.
					sym.addparam(name);
					
					// The next token may be the terminating Cbracket
					// if current parameter is the last and was assigned a default
					// value obtained by calling expression().
					if(match(Tokens::Cbracket))
						break;
					advance();
					
					// Parameters are separated by commas or semicolons
					if(match(Tokens::Comma) || match(Tokens::Semicolon))
						advance();
				}
				advance();	// Move from Cbracket to function's Obrace
				environment.popstack();
			}
			else{
				terminate("Function must be declared with a parameter list, even if empty");
			}
			sym.symbol_stack->setstart(sc.getpos());
			sym.symbol_stack->setend(getblockend(false));
			
			environment.addsymbol(sym);
			latest_symbol = sym;
		}break;
		
		
		case Tokens::Object_Model:{
			assert_unknown(symname, "object name", true);
			
			cout << "Declaring nested model: '" << symname << "\n";
			class_decl();
			
		}break;
		
		
		default:{
			assert_unknown(symname, "variable name", true);
			
			Symbol sym(symname, class_name, tok);
			sym.setaccess((declare_public)?"public":"private");
			environment.addsymbol(sym);
			latest_symbol = sym;
			
			if(lookahead() == Tokens::Assignment)
				advance();
			if(match(Tokens::Assignment)){
				assignment(sym);
				Symbol s = environment.getsymbol(symname);
				//cout << "assignment(): s.getvalue() yields: " << s.getvalue() << endl;
			}
		}break;
	}
	
	if(match(Tokens::Comma)){			// If the next token is a comma,
		declaration(class_name, tok);	// keep declaring with same type
	}
	else if(match(Tokens::Semicolon)){
		//advance();
	}
	
	latest_operation = Tokens::Declaration;
	return symname;
}


// Print all comma-separated expressions until 
// a closing bracket is found. 'lexeme' tells us which
// print variant to use: print() or println()
void Parser::print(string lexeme){
	advance();
	if(match(Tokens::Obracket)){
		advance();
		int argcount = 0;
		while(!match(Tokens::Cbracket)){
			if(match(Tokens::Comma))
				advance();
			string expr = expression().get();
			argcount++;
			cout << expr;
			if(lexeme == "println")
				cout << endl;
		}
		if(argcount <= 0 && lexeme == "println")
			cout << endl;
	}
	else{
		terminate("print: Opening bracket (() expected, but found '"+current.lexeme+"'.");
	}
}


// Evaluate an expression for boolean result (true | false)
bool Parser::eval_bool(Value val){
	string value = val.get();
	if(value != "false" && value != "" && value != "0")
		return true;
	return false;
}


// Keep executing a block of code until condition
// becomes false
Value Parser::while_loop(){
	Value value;
	// Move to opening bracket after 'while'
	advance();
	// Save and restore parser state without resetting
	// the scanner. We will do so within the loop.
	save_parser_state();
	State state = restore_parser_state(false);
	// Evaluate the expression between the brackets
	Value val = expression();
	bool cond = eval_bool(val);
	bool broken = false;	// The loop ended with a break
	
	if(match(Tokens::Obrace)){
		int end = getblockend(true);
		while(cond){
			Model mod("while");
			environment.newstackframe(&mod);
			value = execute_block_content(end);
			environment.popstack();
			
			// If value is "break", we fast forward to 
			// the end of the while loop and terminate it.
			if(value.get() == "break"){
				broken = true;
				while(sc.getpos() != end)
					advance();
				break;
			}
			else if(value.get() == "continue"){
				sc.setpos(state.scannerpos);
				current = state.current;
				previous = state.previous;
				cond = eval_bool(expression());
			}
			
			// Restore parser state manually
			sc.setpos(state.scannerpos);
			current = state.current;
			previous = state.previous;
			
			val = expression();
			cond = eval_bool(val);
			
			// We need to check the condition so that if it
			// proves false, we can simply fats-forward out of
			// the loop. This is necessary because, having manually
			// reset the scanner above, if we allow while() to check
			// the condition in the next iteration and the condition
			// proves false, the while() loop will end, but the scanner
			// has already been reset to the beginning of the while loop.
			// So whether the condition is true or false, the while()
			// loop's block will always be executed one too many times,
			// and local variables might exist beyond their scope.
			if(!cond){
				while(sc.getpos() != end)
					advance();
				break;
			}
		}
	}
	if(broken){
		value.set("");
		value.settype(Tokens::None);
	}
	
	return value;
}



// Execute block of code once if condition is true
Value Parser::if_condition(){
	Value value;
	
	advance();	// Move to opening bracket after 'if'
	advance();	// Enter the conditional expression
	
	// Save and restore parser state without resetting
	// the scanner. We will do so within the loop.
	save_parser_state();
	State state = restore_parser_state(false);
	// Evaluate the expression between the brackets
	Value val = expression();
	
	if(match(Tokens::Cbracket)){
		// We're at a closing bracket; advance to the
		// opening brace
		advance();
	}
	else{
		cout << "Found " << current.lexeme << " instead of ')'\n";
		terminate();	// For debugging
	}
	
	bool cond = eval_bool(val);
	// Save parser state at the opening brace
	save_parser_state();
	
	// Determine the end of this if expression, together
	// with all its else clauses.
	int if_end = getblockend(false);
	
	if(lookahead() == Tokens::Else){
		while(lookahead() == Tokens::Else){
			advance();	// Move to 'else'
			advance();	// Move to next token: Tokens::Obrace or Tokens::If
			
			if(match("if")){
				while(!match(Tokens::Obrace))
					advance();
			}
			
			if_end = getblockend(false);
		}
	}
	
	// At this point, we know where the entire if
	// statement ends. So let's return to the start
	// of its first block.
	restore_parser_state(true);
	
	if(match(Tokens::Obrace)){
		int end = getblockend(true);
		if(cond){
			// Condition is true, so execute the block
			// and skip the rest to the end of the entire if
			// statement.
			Model mod("if");
			environment.newstackframe(&mod);
			value = execute_block_content(getblockend(true));
			environment.popstack();
			
			while(sc.getpos() != if_end)
				advance();
		}
		else{
			// The main condition of this if statement proved false;
			// so here, we search for 'else if' clauses whose conditions 
			// evaluate to true, or the catch-all 'else' clause.
			while(!cond && sc.getpos() != if_end){
				getblockend(false);
				if(lookahead() == Tokens::Else){
					// Token ahead is 'else', so...
					advance();	// Move to the 'else' token
					advance();	// and proceed to the next token: either an opening brace or 'if'
					
					// If the token after the above 'else' clause is 'if'
					// we evaluate its condition. If the condition tests true,
					// or the scanner's position is equal to where we're to stop,
					// our while() loop's condition will prove false and control
					// will be transfered to the code after this while() loop.
					if(match("if")){
						advance();	// Move to opening bracket
						cond = eval_bool(expression());
					}
					else{
						// This token must be an opening brace.
						// If it is, then this 'else' is the catch-all clause;
						// otherwise, we terminate with an error message.
						if(match(Tokens::Obrace)){
							// It's indeed an opening brace.
							// This block then is the catch-all.
							Model mod("if");
							environment.newstackframe(&mod);
							value = execute_block_content(getblockend(true));
							environment.popstack();
							// Fast forward to the end of the whole if block
							while(sc.getpos() != if_end)
								advance();
							break;
						}
						else{
							terminate("Opening brace expected to start else block but found: "+current.lexeme);
						}
						
					}
				}
			}
			
			// We arrive here either because we got to the end of this
			// if statement, or because an 'else if' clause condition
			// proves true.
			if(sc.getpos() != if_end){
				// We found an else if condition that returned true;
				// Let's execute its block.
				if(match(Tokens::Obrace)){
					Model mod("if");
					environment.newstackframe(&mod);
					value = execute_block_content(getblockend(true));
					environment.popstack();
					// Fast forward to block if_end
					while(sc.getpos() != if_end)
						advance();
				}
				else{
					terminate("Opening brace expected to start if block.1");
				}
			}
		}
	}
	else{
		terminate("Opening brace expected to start if block.2");
	}
	
	return value;
}


string Parser::numtostring(double num){
	ostringstream oss;
	oss << num;
	return oss.str();
}


// Increment a value by one
Value Parser::increment(Symbol& sym){
	Value val = sym.getvalueobject();
	
	Tokens symvaltype = val.gettype();
	if(symvaltype == Tokens::Number){
		double symval = val.tonumber();
		symval += 1;
		Value v(numtostring(symval), Tokens::Number);
		sym.setvalue(v);
		environment.updatesymbol(sym);
	}
	
	return val;
}


// Decrement a value by one
Value Parser::decrement(Symbol& sym){
	Value val = sym.getvalueobject();
	
	Tokens symvaltype = val.gettype();
	if(symvaltype == Tokens::Number){
		double symval = val.tonumber();
		symval -= 1;
		Value v(numtostring(symval), Tokens::Number);
		sym.setvalue(v);
		environment.updatesymbol(sym);
	}
	
	return val;
}


// Current token is Tokens::Assignment. We advance()
// once and fetch the expression next to '=' and assign
// to 'sym'.
void Parser::assignment(Symbol& sym){
	string assignop = current.lexeme;
	Tokens assign_type = get_assignop_tok(assignop);
	advance();	//Move past the assignment symbol
	
	switch(sym.getclass()){
		case Tokens::Object:{
			bool address_assign = false;
			
			if(match(Tokens::Address_of)){
				address_assign = true;
				advance();
			}
			
			Symbol sym_rhs = environment.getsymbol(current.lexeme);
			if(sym.getclassname() != sym_rhs.getclassname()){
				terminate("Cannot assign an object of type "+sym_rhs.getclassname()+" to an object of type "+sym.getclassname()+".");
			}
			else if(assign_type != Tokens::Assign){
				terminate("Impossible assigment operation:");
			}
			
			// Assignment is legal, so proceed
			if(address_assign){
				sym.symbol_stack = sym_rhs.symbol_stack;
			}
			else{
				if(sym.symbol_stack != nullptr)
					delete sym.symbol_stack;
				sym.symbol_stack = new Model(sym.getname());
				*sym.symbol_stack = *sym_rhs.symbol_stack;
			}
		}break;
				
		case Tokens::Function:{
			terminate("You cannot assign to a function.");
		}break;
				
		default:{
			Value val = expression();
			sym.setvalue(val);
		}break;
	}
	
	environment.updatesymbol(sym);
	latest_operation = Tokens::Assignment;
}



// Execute the main body of a function.
// Current token should be Tokens::Obrace (i.e. {);
// therefore, advance() before executing.
Value Parser::execute_block_content(int end){
	advance();	// Step past Tokens::Obrace into code block
	Value val;
	while(sc.getpos() != end){
		val = expression();
		if(val.get() == "break"){
			while(sc.getpos() != end)
				advance();
			break;
		}
		else if(val.get() == "continue"){
			break;
		}
		// 'return' terminates a function before its end.
		// If 'return' is followed by an expression, that
		// expression is evaluated and its value is returned
		// to the caller; else the function returns an empty string.
		// 5 that 'return' is not necessary to terminate the
		// function: when it gets to its end, the function will
		// terminate.
		
		if(match(Tokens::Return)){
			if(lookahead() != Tokens::Semicolon){
				advance();
				val = expression();
			}
			break;
		}
	}
	
	return val;
}



Value Parser::function(){
	Value val;
	Symbol sym = environment.getsymbol(current.lexeme);
	vector<string> params = sym.getparams();	// The formal parameters of this function
	vector<Value> args;		// This will hold its actual parameters
	
	advance();
	if(match(Tokens::Obracket)){
		//cout << "Executing function: " << sym.getname() << endl;
		advance();	// Move into param list
		// Now fetch all the arguments with which this function was called
		// and save their values in args above.
		while(!match(Tokens::Cbracket)){
			if(match(Tokens::Comma))
				advance();
			if(match(Tokens::Cstring)){
				// Fetch the symbol with this name
				Symbol s = environment.getsymbol(current.lexeme);
				Tokens type = s.getclass();	// Obtain its type
				if(type != Tokens::None){
					switch(type){
						case Tokens::Object:{
							// Objects do not have immediate values;
							// so simply save its name and the fact that it is an object.
							Value v(s.getname(), Tokens::Object);
							args.push_back(v);
							// We must advance here because we're fetching this argument manually, 
							// else next argument may not be processed correctly.
							advance();
						}break;
						
						case Tokens::Function:{
							// Todo
						}break;
						
						default:{	// The symbol is a variable of a simple type;
							// so simply evaluate and save its value
							Value v = expression();
							args.push_back(v);
						}break;
					}
				}
				else{
					terminate("Unknown function argument '"+current.lexeme+"'.");
				}
			}
			else{	// This argument is a literal expression
				Value v = expression();
				args.push_back(v);
			}
		}
		/*
		Don't forget that function() was called by factor(). Hereafter, we will
		return to factor(), which will call advance() before it returns. So,
		after fetching the called function's arguments above, there is no need
		to advance(). If we do, we may execute code outside the parameter list,
		which will certainly lead to unwanted behaviour. The next token after
		fetching parameters above is Tokens::Cbracket (i.e. closing bracket). We
		have to allow the scanner to pause there until it is necessary to advance() 
		below or outside function().
		*/
	}
	else{
		terminate("Function must be called with a parameter list, even if empty.");
	}
	
	// If number of actual parameters is less than 
	// or equal to that of formal parameters, do the following:
	// (Note: If actual params are less than formal params,
	// then the excess formal params will retain their default values)
	if(args.size() <= params.size()){
		// Install the function's stack
		environment.newstackframe(sym.symbol_stack);
		
		int i=0;	// Index into argument list
		for(Value v : args){
			if(i >= params.size()){
				terminate("Too many arguments to function '"+sym.getname()+"'.");
			}
			Symbol symbol = environment.getsymbol(params.at(i++));	// Fetch a symbol by name
			//Value v = args.at(i++);
			if(v.gettype() == Tokens::Object){	// If this argument is an object
				Symbol symb = environment.getsymbol(v.get());
				// assign its symbol stack to the corresponding formal parameter
				symbol.symbol_stack = symb.symbol_stack;
			}
			else{
				// Argument is neither an object nor a function.
				symbol.setvalue(v);	// Simply pass its value to this parameter
			}
			environment.updatesymbol(symbol);	// Save this change on the current stack
		}
		
		// Save current state of the parser and reset
		// the scanner to the function's block start.
		save_parser_state();
		sc.setpos(sym.symbol_stack->getstart());
		
		// Now execute the function's body. (Note that
		// we have not called advance() because execute_block_content()
		// will do so. If advance() is invoked here, we may skip some
		// important tokens.
		Model mod(sym.getname());
		environment.newstackframe(&mod);
		val = execute_block_content(sym.symbol_stack->getend());
		environment.popstack();
		
		// Uninstall the symbol's stack frame
		// and restore the parser's state.
		environment.popstack();
		restore_parser_state(true);
	}
	else{
		// Number of formal parameters disagrees with
		// that of actual parameters. Display an error.
		int psize = params.size();
		int asize = args.size();
		string str1 = (psize > 1)?"parameters":"parameter";
		string str2 = (asize > 1)?"were":"was";
		terminate("'"+sym.getname()+"' takes "+to_string(psize)+" "+str1+", but "+to_string(asize)+" "+str2+" passed.");
	}
	
	return val;
}

// Current token is Tokens::Not; so we're
// inverting the value of its right hand side expression.
Value Parser::invert(){
	Value val;
	
	advance();	// Move to target expression
	// expression() is passed false to prevent it from
	// causing factor to advance after fetching the target
	// expression. If factor() is allowed to advance (its
	// default behaviour), by the time we return to our
	// original caller, we would have advance()ed past the
	// next valid token after this expression.
	Value v = expression(false);
	
	switch(v.gettype()){
		case Tokens::Number:{
			double num = v.tonumber();
			if(num != 0){
				val.set("0");
			}
			else{
				val.set("1");
			}
			val.settype(Tokens::Boolean);
		}break;
		
		
		case Tokens::String:{
			if(v.get() != ""){
				val.set("");
			}
			else{
				val.set("true");
			}
			val.settype(Tokens::Boolean);
		}break;
		
		
		case Tokens::Boolean:{
			if(v.get() != "false"){
				val.set("false");
			}
			else{
				val.set("true");
			}
			val.settype(Tokens::Boolean);
		}break;
		
		default: break;
	}
	
	return val;
}



// Scan object for blocks of executable code
// and execute them.
Value Parser::execute_object(int end){
	Value val;
	while(sc.getpos() != end){
		if(match(Tokens::Exec_Block)){
			advance();	// After this line, the next token should be Tokens::Obrace
			if(match(Tokens::Obrace)){
				// We've found executable code. 
				// Find out where this block ends, but do not
				// advance() past the opening brace (i.e. true) because
				// execute_block_content() expects to start at an
				// opening brace.
				int end = getblockend(true);
				val = execute_block_content(end);
			}
			else{
				terminate("'{' expected after '"+previous.lexeme+"' but found '"+current.lexeme+"'");
			}
		}
		advance();
	}
	
	return val;
}



// This assists factor for evaluating symbols,
//especially object members.
Value Parser::evaluate(Symbol& sym){
	Value val;
	
	switch(sym.getclass()){
		case Tokens::Function:{
			val = function();
		}break;
										
		case Tokens::Object:{
			val = execute_object(sym.symbol_stack->getend());
		}break;
										
		default:{
			val = sym.getvalueobject();
		}break;
	}
	return val;
}



Value Parser::execute_object_ctor(string objname, bool is_symbol){
	Value val;
	string model_name = objname;
	advance();	// Move to opening bracket
					
	// Save current parser state and enter the target
	// object's scope.
	save_parser_state();
	Model scope("");
	if(is_symbol){
		Symbol sym = environment.getsymbol(objname);
		scope = *sym.symbol_stack;
	}
	else scope = environment.getmodel(model_name);
	
	environment.newstackframe(&scope);
	sc.setpos(scope.getstart());
	advance();
					
	// Search for __ctor in the object's model
	while(sc.getpos() != scope.getend()){
		if(match(Tokens::Object_Ctor))
			break;
		advance();
	}
	if(sc.getpos() == scope.getend()){
		// We got to the end of this model and 
		// did not find __ctor. Terminate with an
		// error message.
		terminate("'"+scope.getname()+"' does not define an object function.");
	}
	advance();	// OK, we found __ctor. Move to opening bracket
	if(match(Tokens::Obracket)){
		// We found the opening bracket: __ctor takes parameters
		advance();	// Step into the list of arguments
		while(!match(Tokens::Cbracket)){
			if(match(Tokens::Comma))
				advance();
							
			Symbol arg = environment.getsymbol(current.lexeme);
			if(arg.getname() == ""){
				terminate("Unknown symbol '"+current.lexeme+"'");
			}
			// Obtain the current state of the parser and save
			// it, without resetting the parser. We'll need it again.
			save_parser_state();
			State parser_state = restore_parser_state(false);
							
			// Now reset the parser to the state we were in
			// before entering this scope. We want to fetch
			// the next argument with which the object function
			// __func is called.
			restore_parser_state(true);
							
			// Now we're back at the opening bracket.
			// Fetch next argument.
			advance();
			
			// Are we at a closing bracket yet?
			// Obviously, __func takes more parameters that
			// than we have. This is an error!
			if(match(Tokens::Cbracket))
				terminate(objname+"'s __func takes more parameters than were passed.");
			
			// This lexeme could be a comma. Skip one or more
			// of them until you find something different
			while(match(Tokens::Comma))
				advance();
							
			Value val;
			if(match(Tokens::Not)){
				// ! means skip this argument
				val.set("skipped");
				val.settype(Tokens::None);
			}
			else val = expression();
							
			// Save the parser state and return to the
			// object's scope, where we found __func
			save_parser_state();
							
			// Manually restore the previously saved parser state
			sc.setpos(parser_state.scannerpos);
			current = parser_state.current;
			previous = parser_state.previous;
							
			if(val.get() != "skipped"){
				arg.setvalue(val);
				environment.updatesymbol(arg);
			}
			advance();
		}
		// At this point, we're at __func's closing bracket.
		// We advance to its opening brace.
		advance();
	}
					
	val = execute_block_content(getblockend(true));
	environment.popstack();
	restore_parser_state(true);
	
	// It is possible that we called __ctor with an empty
	// parameter list; example test();
	// If __ctor takes no arguments, then we will never
	// return to test() until __ctor is done. In that case,
	// our next token upon returning to test() will be an
	// opening bracket. The next token after this is where 
	// the rest of the program continues. expression() will 
	// therefore certainly crash on this next token, which is 
	// a closing bracket. So we do this:
	while(!match(Tokens::Semicolon))
		advance();
	
	if(is_symbol){
		Symbol sym = environment.getsymbol(objname);
		*sym.symbol_stack = scope;
		environment.updatesymbol(sym);
	}
	
	return val;
}



Value Parser::factor(bool fetch_next){
	Value val;
	
	switch(current.token){
		/*
		Is this token a character string? (Note that  character string
		is not a string constant) If it is, determine if it is
		a type specifier, an identifier or a language keyword.
		*/
		case Tokens::Cstring:{
			Tokens tok;
			if(is_typespec(current.lexeme, tok)){
				if(lookahead() == Tokens::Dot){
					// Current token is a model, which is a type specifier;
					// but it is followed by Tokens::Dot, indicating member access.
					// We install the model's stack and determine whether the request 
					// is grantable. The request is grantable if the requested member 
					// is accessible from the current scope.
					if(tok == Tokens::Object){
						Model tgtmod = environment.getmodel(current.lexeme);
						advance();		// Advance to the dot
						
						// Install the stack frame
						environment.newstackframe(&tgtmod);
						active_models.push(tgtmod.getname());
						
						// Fetch the member after the dot
						advance();
						
						if(environment.symbol_exists(current.lexeme, true)){
							// Requested symbol exists. So get it.
							Symbol member = environment.getsymbol(current.lexeme);
							// We are trying to access a member of an external model
							// directly. Such access is only possible if that member
							// was declared as public.
							if((member.getaccess() == "public") || (tgtmod.getname() == active_models.get())){
								val = evaluate(member);
							}
							else{
								terminate("'"+member.getname()+"' in model '"+tgtmod.getname()+"' is private");
							}
						}
						else terminate("'"+tgtmod.getname()+"' has no member named '"+current.lexeme+"'");
							
						environment.popstack();
						active_models.pop();
					}
				}
				else if(lookahead() == Tokens::Obrace){
					// Anonymous model instance. We execute code between
					// the opening and closing braces as though we're executing
					// an actual object. But outside the closing brace, this
					// anonymous object ceases to exist.
					Model scope = environment.getmodel(current.lexeme);
					advance();	// Move to opening brace
					
					environment.newstackframe(&scope);
					active_models.push(scope.getname());
					
					execute_block_content(getblockend(true));
					environment.popstack();
				}
				else if(lookahead() == Tokens::Obracket){
					// Anonymous model instance with parameters.
					// Here, this anonymous object acts like a function
					// by calling the model's __ctor code block and
					// passing it the parameters. Thus control is transfered
					// to __func.
					
					// false means we are not executing a real object/symbol
					return execute_object_ctor(current.lexeme, false);
				}
				else{
					declaration(current.lexeme, tok);
				}
			}
			else if(is_identifier(current.lexeme, false)){
				Symbol sym = environment.getsymbol(current.lexeme);
				if(sym.getclass() == Tokens::Object){
					// Install this object's stack frame
					environment.newstackframe(sym.symbol_stack);
					active_models.push(sym.getclassname());
					
					// Is there a dot ahead?
					if(lookahead() == Tokens::Dot){
						// Yes, a dot is next. Move to it
						advance();
						// Then move on to the token beyond the dot
						advance();
						
						string member = current.lexeme;
						environment.newstackframe(sym.symbol_stack);
						if(environment.symbol_exists(member, true)){	// True means search only in the current stack frame
							Symbol symbol = environment.getsymbol(member);
							if(symbol.getaccess() == "private"){
								terminate("'"+symbol.getname()+"' is private to '"+sym.getname()+"'");
							}
							val = evaluate(symbol);
							//cout << sym.getname() << "'s '" << member << "' member requested.\n";
						}
						else{
							terminate(sym.getname()+" has no member called '"+member+"'.");
						}
						environment.popstack();
					}
					// Or is the next token an opening brace
					else if(lookahead() == Tokens::Obrace){
						// An opening brace is ahead. Move to it.
						advance();
						
						// A model instance followed by an opening brace
						// constructs the instance (i.e. an object) manually.
						environment.newstackframe(sym.symbol_stack);
						execute_block_content(getblockend(true));
						environment.popstack();
					}
					// Or maybe the next token is an opening bracket
					else if(lookahead() == Tokens::Obracket){
						
						// This object's constructor is being called.
						// If is has a code block called __ctor, then
						// code within that block will be executed. Else,
						// it is an error.
						val = execute_object_ctor(current.lexeme, true);
					}
					else{
						// We're dealing directly with a stand-alone Object.
						// In this case, it works as a function because we
						// simply execute all of its Tokens::Exec_Block code blocks.
						// If there are no executable code blocks, then nothing happens.
						save_parser_state();
						environment.newstackframe(sym.symbol_stack);
						
						val = execute_object(sym.symbol_stack->getend());
						
						environment.popstack();
						restore_parser_state(true);
						// cout << "factor(): '" << sym.getname() << "' is an object of type " << sym.getclassname() << endl;
					}
					environment.popstack();
					active_models.pop();
				}
				else if(sym.getclass() == Tokens::Function){
					val = function();
				}
				else{
					// OK, the symbol is neither an object nor a function.
					// It is most likely an object of a simple type.
					latest_symbol = environment.getsymbol(current.lexeme);
					// We can carry out many operations on this symbol.
					// This is the right place to define such operations;
					// but for now, we simply get its value.
					val = latest_symbol.getvalueobject();
					
					if(lookahead() == Tokens::Increment){
						advance();
						increment(latest_symbol);
					}
					else if(lookahead() == Tokens::Decrement){
						advance();
						decrement(latest_symbol);
					}
					//cout << "factor(): Value of lone symbol: " << latest_symbol.getvalue() << endl;
				}
			}
			else if(is_keyword(current.lexeme)){
				Tokens token = get_keyword_tok(current.lexeme);
				// A language keyword, like print
				switch(token){
					case Tokens::Print:{
						// Call print(), passing it the lexeme representing the kind
						// of print operation to carry out.
						print(current.lexeme);
					}break;
					
					case Tokens::While:{
						val = while_loop();
					}break;
					
					case Tokens::If:{
						val = if_condition();
					}break;
					
					case Tokens::Else:{
						// Do nothing for now
					}break;
					
					case Tokens::Break:{
						val.set("break");
						val.settype(Tokens::Break);
					}break;
					
					case Tokens::Continue:{
						val.set("continue");
						val.settype(Tokens::Continue);
					}break;
					
					default: cout << "Unknown keyword: " << current.lexeme << endl; break;
				}
			}
			else if(match("True") || match("False")){
				val.set((current.lexeme == "True")?"true":"false");
				val.settype(Tokens::Boolean);
			}
			else{
				terminate("Unknown symbol '"+current.lexeme+"'.");
			}
		}break;
		
		
		// We are assigning to the latest symbol
		case Tokens::Assignment:{
			assignment(latest_symbol);
		}break;
		
		
		case Tokens::Number:{
			val.settype(Tokens::Number);
			val.set(current.lexeme);
		}break;
		
		
		case Tokens::String:{
			val.settype(Tokens::String);
			val.set(current.lexeme);
		}break;
		
		// Pre-increment
		case Tokens::Increment:{
			advance();
			Symbol sym = environment.getsymbol(current.lexeme);
			increment(sym);
			Value v = sym.getvalueobject();
			val.settype(v.gettype());
			val.set(v.get());
		}break;
		
		// Pre-decrement
		case Tokens::Decrement:{
			advance();
			Symbol sym = environment.getsymbol(current.lexeme);
			decrement(sym);
			Value v = sym.getvalueobject();
			val.settype(v.gettype());
			val.set(v.get());
		}break;
		
		
		case Tokens::Character:{
			val.settype(Tokens::Character);
			val.set(current.lexeme);
		}break;
		
		
		case Tokens::Not:{
			val = invert();
		}break;
		
		
		case Tokens::Obracket:{
			advance();	// Step into the bracket-delimited expression
			val = expression();
			
			if(lookahead() == Tokens::Semicolon)
				advance();
		}break;
		
		
		default: break;
	}
	
	// This call to advance() is important to 
	// determine what action term() should take when
	// factor returns to it.
	if(fetch_next) advance();
	return val;
}



Value Parser::term(bool fetch_next){
	Value val = factor(fetch_next);
	
	while(match(Tokens::Mathop)){
		Tokens tok = get_mathop_tok(current.lexeme);
		if(tok == Tokens::Times){
			advance();
			val = val*factor(fetch_next);
		}
		else if(tok == Tokens::Divide){
			advance();
			val = val/factor(fetch_next);
		}
		else if(tok == Tokens::Modulo){
			advance();
			val = val%factor(fetch_next);
		}
		else if(tok == Tokens::Power){
			advance();
			val = val^factor(fetch_next);
		}
		else break;
	}
	
	
	while(match(Tokens::Comparison)){
		Tokens comptok = get_comparison_tok(current.lexeme);
		
		if(comptok == Tokens::Equal_To){
			advance();
			val = val==factor(fetch_next);
		}
		else if(comptok == Tokens::Not_Equal){
			advance();
			val = val!=factor(fetch_next);
		}
		else if(comptok == Tokens::Greater_Or_Equal){
			advance();
			val = val>=factor(fetch_next);
		}
		else if(comptok == Tokens::Less_Or_Equal){
			advance();
			val = val<=factor(fetch_next);
		}
		else if(comptok == Tokens::Less_Than){
			advance();
			val = val<factor(fetch_next);
		}
		else if(comptok == Tokens::Greater_Than){
			advance();
			val = val>factor(fetch_next);
		}
		else break;
	}
	
	// The last call to factor() that breaks the
	// loop and brings us here has advance()ed to
	// a new token, preparing us for the next call
	// to expression().
	return val;
}



Value Parser::expression(bool fetch_next){
	Value val = term(fetch_next);
	//if(!fetch_next) advance();
	
	while(match(Tokens::Mathop)){
		Tokens tok = get_mathop_tok(current.lexeme);
		if(tok == Tokens::Plus){
			advance();
			val = val+term(fetch_next);
		}
		else if(tok == Tokens::Minus){
			advance();
			val = val-term(fetch_next);
		}
		else break;
	}
	
	while(match(Tokens::Comparison)){
		Tokens comptok = get_comparison_tok(current.lexeme);
		
		if(comptok == Tokens::And){
			advance();
			val = val&&term(fetch_next);
		}
		else if(comptok == Tokens::Or){
			advance();
			val = val||term(fetch_next);
		}
		else break;
	}
	
	// Similar to the comment in term() above; but
	// after here, we are returning to our caller
	// where parsing will continue from the new
	// unevaluated token.
	return val;
}



#endif
