﻿#ifndef SYMBOL_HPP
#define SYMBOL_HPP

#include <string>
#include <map>
#include "value.hpp"

using namespace std;

class Model;	// Forward declaration: We'll use Model in Symbol and vice versa

class Symbol{
	private:
	string name;
	Tokens symbol_class;	// A function, variable, model, or object
	string symbol_class_name;
	Value value;
	vector<string> params;	// Relevant only when this symbol is a function
	string access;
	
	public:
	// symbol_stack is relevant where this symbol is a model instance.
	// We make it public so can initialize it from the parser.
	Model* symbol_stack;
	
	// Initialize private memebers
	Symbol(string n, string clsname, Tokens cls) :
		name{n},
		symbol_class{cls},
		symbol_class_name{clsname},
		symbol_stack{nullptr}
	{}
	
	/* We may uncomment this code in future.
	~Symbol(){
		if(symbol_stack != nullptr)
			delete symbol_stack;
	}
	*/
	
	// Getter methods
	string getname(){ return name; }
	Tokens getclass(){ return symbol_class; }
	string getclassname(){ return symbol_class_name; }
	Value getvalueobject(){ return value; }
	string getvalue(){ return value.get(); }
	Model* getmodelstack(){ return symbol_stack; }
	int getparamcount(){ return params.size(); }
	string getaccess(){ return access; }
	
	// Setter methods
	// We do not define setname() because once created, 
	// a symbol cannot be renamed
	void setvalue(Value val){ value = val; }
	void setvalue(string val){ value.set(val); }
	void setclass(Tokens sym_class){ symbol_class = sym_class; }
	void setmodelstack(Model* mod){ symbol_stack = mod; }
	void addparam(string param){ params.push_back(param); }
	vector<string> getparams(){ return params; }
	void setaccess(string symaccess){ access = symaccess; }
};



class Function{
	private:
	string name;
	string owner;
	map<string, Symbol> symbols;
	map<string, Symbol>::iterator sym_it;
	
	Function(string n, string owner){
		name = n;
		this->owner = owner;
	}
};



class Model{
	private:
	bool hasCtor;
	string name;
	int block_start;
	int block_end;
	
	map<string, Symbol> symbols;
	map<string, Symbol>::iterator symbol_it;
	
	
	public:
	Model(string n) : name{n}{}
	
	void setstart(int start){
		block_start = start;
	}
	
	void setend(int end){
		block_end = end;
	}
	
	int getstart(){
		return block_start;
	}
	
	int getend(){
		return block_end;
	}
	
	string getname(){
		return name;
	}
	
	void hasctor(bool yes_or_no){
		hasCtor = yes_or_no;
	}
	
	bool hasctor(){
		return hasCtor;
	}
	
	
	void addsymbol(Symbol sym);
	Symbol getsymbol(string name);
	bool symbol_exists(string name);
	void updatesymbol(Symbol sym);
	int countsymbols();
};



void Model::addsymbol(Symbol sym){
	symbols.insert(pair<string, Symbol>(sym.getname(), sym));
	//cout << "Symbols: " << symbols.size() << endl;
}


bool Model::symbol_exists(string name){
	if(symbols.count(name) > 0)
		return true;
	return false;
}


Symbol Model::getsymbol(string name){
	if(symbol_exists(name))
		return symbols.find(name)->second;
	Symbol sym("", "", Tokens::None);
	return sym;
}


void Model::updatesymbol(Symbol sym){
	if(symbol_exists(sym.getname()))
		symbols.find(sym.getname())->second = sym;
}

int Model::countsymbols(){
	return symbols.size();
}

#endif
