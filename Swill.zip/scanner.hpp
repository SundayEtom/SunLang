﻿#ifndef SCANNER_HPP
#define SCANNER_HPP

#include <string>
#include <fstream>
#include <iostream>
#include <cctype>
#include <cstdlib>
#include "defs.hpp"		// include token definitions

using namespace std;

class Scanner{
	private:
	int index;
	string text, lexeme;
	Tokens token;
	char prevtok, curtok, nexttok;
	
	
	/*
	Get next character from source text and save it in curtok.
	But before that, check the next character position;
	if it is greater than or equal to the length of the source
	text, return false, indicating that we're at the end of
	the source text.
	*/
	bool advance();
	
	
	/*
	Push back a character, to be read again later.
	*/
	void pushback(){
		nexttok = curtok;
		curtok = prevtok;
		if(index > 0) index--;
		if(current_char > 0) current_char--;
	}
	
	
	
	
	
	public:
	/*
	The constructor takes a single parameter of type string.
	It attempts to open a file input stream with this parameter.
	If the attempt succeeds, then the parameter is a filename and
	Scanner() reads and stores its content in text above. However,
	if the attempt fails, then Scanner() assumes the parameter
	is a source text, which it simply assigns to text.
	*/
	Scanner(string text_or_file);
	
	
	
	
	// Return current lexeme
	string getlexeme(){
		return lexeme;
	}
	
	
	// Return scanner position
	int getpos(){
		return index;
	}
	
	
	// Set scanner position
	void setpos(int pos){
		if(pos >= 0 && pos < text.length())
			index = pos;
	}
	
	
	
	/*
	Get the next character by calling advance and determine what
	token to return to parser. We skip both line and block comments.
	If a newline character is encountered, increment linecount, a global
	integer variable defined in defs.hpp, then call scan() recursively.
	*/
	Tokens scan();
	
};



Scanner::Scanner(string text_or_file) :
	index{2}, lexeme{""}, text{""}
{
	ifstream ifs(text_or_file);
	if(ifs){
		string line;
		while(!ifs.eof()){
			getline(ifs, line);
			text += line + "\n";
		}
		ifs.close();
		//cout << "Initialized from source file.\n";
	}
	else{
		text = text_or_file;
		//cout << "Initialised from text.\n";
	}
}



bool Scanner::advance(){
	if(nexttok == '\0' || ++index >= text.length()){
		//exit(EXIT_SUCCESS);
		return false;
	}
	else{
		prevtok = curtok;
		curtok = text.at(index);
		current_char++;
		
		if(index+1 < text.length()){
			nexttok = text.at(index+1);
		}
		else{
			nexttok = '\0';
		}
	}
	return true;
}





Tokens Scanner::scan(){
	lexeme = "";
	while(advance()){
		if(isspace(curtok) && curtok != '\n'){
			while(isspace(curtok)){	// Skip blanks.
				advance();
			}
			pushback();		// Push back the non-blank character that breaks the loop
			return scan();
		}
			
		else if(isalpha(curtok) || curtok == '_'){
			while(isalnum(curtok) || curtok == '_'){
				lexeme += curtok;
				advance();
			}
			pushback();
			if(lexeme == "__stop")
				return Tokens::Exec_Stop;
			else if(lexeme == "__decl")
				return Tokens::Decl_Block;
			else if(lexeme == "__exec")
				return Tokens::Exec_Block;
			else if(lexeme == "return")
				return Tokens::Return;
			return Tokens::Cstring;		// Character string
		}
			
		/*
		Return either a floating point number that begins 
		with a dot, or a dot on its own for member access
		*/
		else if(curtok == '.'){
			lexeme = curtok;
			if(isdigit(nexttok)){
				advance();
				while(isdigit(curtok)){
					lexeme += curtok;
					advance();
				}
				pushback();
				return Tokens::Number;
			}
			else{
				return Tokens::Dot;
			}
		}
			
		/*
		Return a number with zero or one dot
		*/
		else if(isdigit(curtok)){
			int dots = 0;
			while(isdigit(curtok) || curtok == '.'){
				if(curtok == '.'){
					dots++;
					if(dots > 1){
						break;
					}
				}
				lexeme += curtok;
				advance();
			}
			pushback();
			return Tokens::Number;
		}
		
		// Skip C/C++ style comments
		else if(curtok == '/'){
			if(nexttok == '/'){	// Line comment
				while(curtok != '\n')
					advance();
				current_line++;
				current_char = 1;
				return Tokens::Comment;
			}
			else if(nexttok == '*'){	// Multi-line comment
				while(advance()){
					if(curtok == '\n'){
						current_line++;
						current_char = 1;
					}
					else if(curtok == '*' && nexttok == '/'){
						advance();
						break;
					}
				}
				return scan();
			}
			else{	// Arithmetic division sign
				lexeme = curtok;
				return Tokens::Mathop;
			}
		}
		
		// Fetch a string constant, wrapped in double quotes
		else if(curtok == '"'){
			while(advance()){
				if(curtok == '"' && prevtok != '\\')
					break;
				lexeme += curtok;
			}
			return Tokens::String;
		}
		
		// Deal with newline characters
		else if(curtok == '\n'){
			current_line++;
			current_char = 1;
			
			return scan();
		}
		
		// Get a comma
		else if(curtok == ','){
			lexeme = curtok;
			return Tokens::Comma;
		}
		
		// Get a semicolon
		else if(curtok == ';'){
			lexeme = curtok;
			return Tokens::Semicolon;
		}
		
		// Get an opening bracket
		else if(curtok == '('){
			lexeme = curtok;
			return Tokens::Obracket;
		}
		
		// Get a closing bracket
		else if(curtok == ')'){
			lexeme = curtok;
			return Tokens::Cbracket;
		}
		
		// Get an opening brace
		else if(curtok == '{'){
			lexeme = curtok;
			return Tokens::Obrace;
		}
		
		// Get a closing brace
		else if(curtok == '}'){
			lexeme = curtok;
			return Tokens::Cbrace;
		}
		
		// Get an assignment token
		else if(curtok == '='){
			lexeme = curtok;
			if(nexttok == '='){
				advance();
				lexeme += curtok;
				return Tokens::Comparison;
			}
			return Tokens::Assignment;
		}
		
		// Unknown token: break and return Tokens::None
		else{
			break;
		}
	}
		
	return Tokens::None;
}

#endif
