﻿#ifndef VALUE_HPP
#define VALUE_HPP

#include <string>
#include <sstream>
#include "defs.hpp"

using namespace std;


class Value{
	private:
	string value;
	Tokens type;
	
	
	public:
	Value(string str, Tokens t){
		value = str;
		type = t;
	}
	
	Value(){	// Default constructor
		value = "";
		type = Tokens::None;
	}
	
	
	string get(){ return value; }
	Tokens gettype(){ return type; }
	void set(string val){ value = val; }
	void settype(Tokens t){ type = t; }
	
	// Convert value to a number
	double tonumber();
	Value operator+(Value rhs);
	Value operator-(Value rhs);
	Value operator*(Value rhs);
	Value operator/(Value rhs);
	Value operator%(Value rhs);
};



double Value::tonumber(){
	stringstream ss(value);
	double val;
	ss >> val;
	
	return val;
}

Value Value::operator+(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					string v = to_string(val_lhs+val_rhs);
					val.set(v);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}



Value Value::operator-(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					string v = to_string(val_lhs-val_rhs);
					val.set(v);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}


Value Value::operator*(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					value = to_string(val_lhs*val_rhs);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					int times = (int)rhs.tonumber();
					string str = value;
					while(times-- > 0)
						value += str;
					val.set(value);
					val.settype(Tokens::String);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}



Value Value::operator/(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					if(val_rhs == 0){
						cout << "Division by zero.\n";
						exit(EXIT_SUCCESS);
					}
					double diff = val_lhs/val_rhs;
					value = to_string(diff);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				case Tokens::Character:{
					double val_lhs = tonumber();
					double val_rhs = (rhs.get().at(0))-'0';
					if(val_rhs == 0){
						cout << "Division by zero.\n";
						exit(EXIT_SUCCESS);
					}
					double diff = val_lhs/val_rhs;
					value = to_string(diff);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}



Value Value::operator%(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					if(val_rhs == 0){
						cout << "Division by zero.\n";
						exit(EXIT_SUCCESS);
					}
					int mod = (int) val_lhs*(int) val_rhs;
					val.set(to_string(mod));
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}






#endif
