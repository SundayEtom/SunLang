﻿#ifndef VALUE_HPP
#define VALUE_HPP

#include <string>
#include <sstream>
#include <iomanip>
#include "defs.hpp"

using namespace std;


class Value{
	private:
	string value;
	Tokens type;
	
	
	public:
	Value(string str, Tokens t){
		value = str;
		type = t;
	}
	
	Value(){	// Default constructor
		value = "";
		type = Tokens::None;
	}
	
	
	string get(){ return value; }
	Tokens gettype(){ return type; }
	void set(string val){ value = val; }
	void settype(Tokens t){ type = t; }
	
	// Convert value to a number
	double tonumber();
	
	// Convert number to string
	string tostring(double num);
	
	// Arithmetic operators
	Value operator+(Value rhs);	// Addition
	Value operator-(Value rhs);	// Subtraction
	Value operator*(Value rhs);	// Multiplication
	Value operator/(Value rhs);	// Division
	Value operator%(Value rhs);	// Modulo
	Value operator^(Value rhs);	// Power
	
	// Relational operators
	Value operator!();	// Not
	Value operator==(Value val);	// Equal to
	Value operator!=(Value val);	// Not Equal to
	Value operator>=(Value val);	// Greater than or equal
	Value operator<=(Value val);	// Less than or equal
	Value operator<(Value val);		// Less than
	Value operator>(Value val);		// Greater than
	Value operator&&(Value val);	// Logical And
	Value operator||(Value val);	// Logical Or
};



double Value::tonumber(){
	stringstream ss(value);
	double val;
	ss >> setprecision(0) >> val;
	
	return val;
}


string Value::tostring(double val){
	string result;
	ostringstream oss;
	oss << val;
	result = oss.str();
	
	return result;
}



Value Value::operator+(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					value = tostring(val_lhs+val_rhs);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				case Tokens::String:{
					value += rhs.get();
					val.set(value);
					val.settype(Tokens::String);
				}break;
				
				case Tokens::Character:{
					double cval = (rhs.get().at(0))-'0';
					value += cval;
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			switch(rhs.gettype()){
				case Tokens::String:
				case Tokens::Number:
				case Tokens::Boolean:
				case Tokens::Character:{
					value += rhs.get();
					val.set(value);
					val.settype(Tokens::String);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}



Value Value::operator-(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					value = tostring(val_lhs-val_rhs);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}


Value Value::operator*(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					value = tostring(val_lhs*val_rhs);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					int times = (int)rhs.tonumber();
					string str = value;
					while(--times > 0)
						value += " "+str;
					val.set(value);
					val.settype(Tokens::String);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}



Value Value::operator/(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					if(val_rhs == 0){
						cout << "Division by zero.\n";
						exit(EXIT_SUCCESS);
					}
					double diff = val_lhs/val_rhs;
					value = tostring(diff);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				case Tokens::Character:{
					double val_lhs = tonumber();
					double val_rhs = (rhs.get().at(0))-'0';
					if(val_rhs == 0){
						cout << "Division by zero.\n";
						exit(EXIT_SUCCESS);
					}
					double diff = val_lhs/val_rhs;
					value = tostring(diff);
					val.set(value);
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}



Value Value::operator%(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					double val_rhs = rhs.tonumber();
					if(val_rhs == 0){
						cout << "Division by zero.\n";
						exit(EXIT_SUCCESS);
					}
					int mod = (int) val_lhs%(int) val_rhs;
					val.set(tostring(mod));
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}




Value Value::operator^(Value rhs){
	Value val;
	switch(type){
		case Tokens::Number:{
			switch(rhs.gettype()){
				case Tokens::Number:{
					double val_lhs = tonumber();
					int val_rhs = (int)rhs.tonumber();
					if(val_rhs == 0){
						val.set("1");
						val.settype(Tokens::Number);
						break;
					}
					double pow = 1;
					for(int i=1; i<=val_rhs; i++){
						pow *= val_lhs;
					}
					val.set(tostring(pow));
					val.settype(Tokens::Number);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	return val;
}


Value Value::operator==(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs == rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs == rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			string lhs = value;
			switch(val.gettype()){
				case Tokens::String:{
					string rhs = val.get();
					retval.set((lhs == rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}



Value Value::operator!=(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs != rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs != rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			string lhs = value;
			switch(val.gettype()){
				case Tokens::String:{
					string rhs = val.get();
					retval.set((lhs != rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}



Value Value::operator>=(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs >= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs >= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Character:{
			double lhs = (double)(value.at(0))-'0';
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs >= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs >= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}



Value Value::operator<=(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs <= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs <= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Character:{
			double lhs = (double)(value.at(0))-'0';
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs <= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs <= rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}



Value Value::operator<(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs < rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs < rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Character:{
			double lhs = (double)(value.at(0))-'0';
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs < rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs < rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}



Value Value::operator>(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs > rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs > rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Character:{
			double lhs = (double)(value.at(0))-'0';
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs > rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs > rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}



Value Value::operator&&(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs && rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs && rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::String:{
					bool v = false;
					if(val.get() != "" && 
						val.get() != "0" && 
						val.get() != "false"
					) v = true;
					retval.set((lhs && v)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Character:{
			double lhs = (double)(value.at(0))-'0';
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs && rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs && rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::String:{
					bool v = false;
					if(val.get() != "" && 
						val.get() != "0" && 
						val.get() != "false"
					) v = true;
					retval.set((lhs && v)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			bool v1 = false;
			if(value != "" && 
				value != "0" && 
				value != "false"
			) v1 = true;
			
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((v1 && rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((v1 && rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::String:{
					bool v2 = false;
					if(val.get() != "" && 
						val.get() != "0" && 
						val.get() != "false"
					) v2 = true;
					retval.set((v1 && v2)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Boolean:{
			switch(val.gettype()){
				case Tokens::Boolean:{
					retval.set(
						(value == "true" && val.get() == "true")
						?"true":"false");
					retval.settype(Tokens::Boolean);
				}
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}


Value Value::operator||(Value val){
	Value retval;
	
	switch(type){
		case Tokens::Number:{
			double lhs = tonumber();
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs || rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs || rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::String:{
					bool v = false;
					if(val.get() != "" && 
						val.get() != "0" && 
						val.get() != "false"
					) v = true;
					retval.set((lhs || v)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Character:{
			double lhs = (double)(value.at(0))-'0';
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((lhs || rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((lhs || rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::String:{
					bool v = false;
					if(val.get() != "" && 
						val.get() != "0" && 
						val.get() != "false"
					) v = true;
					retval.set((lhs || v)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::String:{
			bool v1 = false;
			if(value != "" && 
				value != "0" && 
				value != "false"
			) v1 = true;
			
			switch(val.gettype()){
				case Tokens::Number:{
					double rhs = val.tonumber();
					retval.set((v1 || rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::Character:{
					double rhs = (double)(val.get().at(0))-'0';
					retval.set((v1 || rhs)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				case Tokens::String:{
					bool v2 = false;
					if(val.get() != "" && 
						val.get() != "0" && 
						val.get() != "false"
					) v2 = true;
					retval.set((v1 || v2)?"true":"false");
					retval.settype(Tokens::Boolean);
				}break;
				
				default: break;
			}
		}break;
		
		case Tokens::Boolean:{
			switch(val.gettype()){
				case Tokens::Boolean:{
					retval.set(
						(value == "true" || val.get() == "true")
						?"true":"false");
					retval.settype(Tokens::Boolean);
				}
				
				default: break;
			}
		}break;
		
		default: break;
	}
	
	return retval;
}




#endif
