﻿

model Start{
	
	__exec{
		println((greeting));
		greeting = "Swill is good for you.";
		age(10);
	}

	__decl{
		string greeting = "Hello Swill programmer!";
		
		function age(num yob){
			print("You are ", yob*3, " years old.");
			println();
		}
	}
	
	__exec{
		println(greeting);
		Test{
			string res = test_str();
			println(res);
			string address = "Eponoh No.2, Nko";
			println(address);
		}
		//println(address);	// Error. We are out of Test's scope
	}
	
}


model Test{
	public
	__decl{
		function test_str(){
			println("Test string...");
			return "Done";
		}
	}
	
}


_stop_
