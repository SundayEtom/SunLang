﻿

model Start{
	
	__exec{
		
		num a = age(1983);
		
		if(a <= 17){
			println("You are still too young.");
		}
		else if(a >= 40){
			println("You are above the right age.");
		}
		else if(/*false*/(a==35 && a/5!=7) || /*true*/a!=40){
			println(
				"You are ripe for this, Boss!\n" +
				"\tYou are \"" + age(1986) + "\" years old."
			);
		}
		else{
			println("I don't know your age!");
		}
		/*
		println(greeting);
		greeting = "Swill is good for you.";
		age(1983);
		println(greeting);
		string res = Person("Sunnyside");
		println(res, "*"*8);
		*/
		num n=15;
		while(n){
			println(n--);
		}
		/*
		num n0 = 8;
		num n1 = 0;
		num n2 = 0;
		num n3 = 0;
		
		if(n0){
			println("n0 is: "+n0);
			num number = 190;
			println("In loop: Number is: "+number);
		}
		else if(n1){
			println("n1 is: "+n1);
		}
		else if(n2){
			println("n2 is: "+n2);
		}
		else if(n3){
			println("n3 is: "+n3);
		}
		else{
			println("None of the values is valid.");
			num number = 90;
			println("In loop: Number is: "+number);
		}
		
		println("End of 'if' statement.");
		
		/*
		Person("Gift Simon Enya", !, 13);
		Person person1("Deborah Enang Arikpo", !, 14);
		Person("Arit Effiom", !, !);
		
		Test test;
		Person person{
			name = "Mastersunny";
		}
		
		Person{
			name = "Arit Effiom";
			sex = "Female";
			age = 12;
			//tellname();
		}
		/*
		person{
			name = "Deborah Enang";
			//tellname();
		}
		*/
	}

	__decl{
		string greeting = "Hello Swill programmer!";
		
		function age(num yob){
			string age = 2018-yob;
			//println("You are "+age+" years old.");
			//println(age+" raised to power 2 is "+(age^2));
			return age;
		}
	}
}


model Test{
	public
	__decl{
		function test_str(){
			println("Test string...");
			return "Done";
		}
	}
}



model Person{
	private
	__decl{
		string name;
		string sex = "Female";
		num age = 12;
	}
	
	public
	__decl{
		function tellname(){
			print("My name is ", name);
			println();
		}
	}
	
	__ctor(name){
		println("*"*8);
		println(name, sex, age);
		return "__ctor() execution complete.";
	}
}


_stop_
