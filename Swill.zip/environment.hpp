﻿#ifndef ENVIRONMENT_HPP
#define ENVIRONMENT_HPP

#include <string>
#include <map>
#include <vector>
#include <iostream>		// remove after debugging
#include "symbol.hpp"
#include "utils.hpp"

using namespace std;


// Type specifiers
map<string, Tokens> typespecs{
	{"num",			Tokens::Number			},
	{"string",		Tokens::String			},
	{"model",		Tokens::Object_Model	},
	{"char",		Tokens::Character		},
	{"array",		Tokens::Array			},
	{"function",	Tokens::Function		}
};

// Languge keywords
map<string, Tokens> keywords{
	{"print",		Tokens::Print		},
	{"while",		Tokens::While		},
	{"for",			Tokens::For			},
	{"foreach",		Tokens::Foreach		},
	{"println",		Tokens::Print		},
	{"break",		Tokens::Break		},
	{"return",		Tokens::Return		},
	{"continue",	Tokens::Continue	},
	{"public",		Tokens::Public		},
	{"private",		Tokens::Private		},
	{"if",			Tokens::If			},
	{"else",		Tokens::Else		}
};


// Assignment operators
map<string, Tokens> assignops{
	{"=",		Tokens::Assign			},
	{"+=",		Tokens::Plus_Assign		},
	{"-=",		Tokens::Minus_Assign	},
	{"*=",		Tokens::Mult_Assign		},
	{"/=",		Tokens::Div_Assign		},
	{"%=",		Tokens::Mod_Assign		},
	{"++",		Tokens::Increment		},
	{"--",		Tokens::Decrement		}
};


// Math operators
map<string, Tokens> mathops{
	{"+",		Tokens::Plus	},
	{"-",		Tokens::Minus	},
	{"*",		Tokens::Times	},
	{"/",		Tokens::Divide	},
	{"%",		Tokens::Modulo	},
	{"^",		Tokens::Power	}
};


// Relational operators
map<string, Tokens> comparison_ops{
	{">",		Tokens::Greater_Than		},
	{"<",		Tokens::Less_Than			},
	{"==",		Tokens::Equal_To			},
	{"!",		Tokens::Not					},
	{"!=",		Tokens::Not_Equal			},
	{">=",		Tokens::Greater_Or_Equal	},
	{"<=",		Tokens::Less_Or_Equal		},
	{"&&",		Tokens::And					},
	{"||",		Tokens::Or					}
};

map<string, Tokens>::iterator map_iter;


// Symbol table -- may be removed soon
map<string, Symbol> symbols{};
map<string, Symbol>::iterator symbol_it;
	
// Model block table. Each declared model in a S'will
// program will be saved here.
map<string, Model> models{};
map<string, Model>::iterator model_it;


// Model execution stack:
// During its execution, each model must push its frame
// on to this stack, to avoid name conflicts and guarantee
// data privacy.
vector<Model*> ModelStack;
int curstack;


class Environment{
	private:
	
	
	public:
	Environment(){}
	
	int newstackframe(string framename);
	int newstackframe(Model* frame);
	Model* popstack();
	
	// Symbol table routines
	void addsymbol(Symbol sym);
	Symbol getsymbol(string name);
	bool symbol_exists(string lex, bool decl);
	void updatesymbol(Symbol sym);
	int getsymbolstack(string symname);
	
	// Model table routines
	void addmodel(Model mod);
	Model getmodel(string name);
	bool model_exists(string lex);
	void updatemodel(Model mod);
	Model* getmodelstack(string symname);
	int countmodels();
	int countmodelstacks();
	
} environment;


// Set up a new stack frame, using new
int Environment::newstackframe(string framename){
	ModelStack.push_back(new Model(framename));
	curstack = ModelStack.size()-1;
	return curstack;
}

// Set up a new stack frame (overload)
int Environment::newstackframe(Model* frame){
	ModelStack.push_back(frame);
	curstack = ModelStack.size()-1;
	return curstack;
}

// Remove a frame from the top of the stack
Model* Environment::popstack(){
	if(ModelStack.size() <= 0)
		return nullptr;
		
	Model* frame;
	frame = ModelStack.at(ModelStack.size()-1);
	ModelStack.erase(ModelStack.end()-1);
	curstack = ModelStack.size()-1;
	//cout << "STACK FRAMES: " << curstack << endl;
	return frame;
}

/*
The following routines simply call the public
methods of the current stack frame.
*/


// Add a symbol to the stack
void Environment::addsymbol(Symbol sym){
	ModelStack.at(curstack)->addsymbol(sym);
}


// Make sure we do not try to redeclare a symbol
bool Environment::symbol_exists(string lex, bool decl){
	string curmodel = active_models.get();
	if(decl){
		if(ModelStack.at(curstack)->symbol_exists(lex))
			return true;
	}
	else{
		for(int i=curstack; i>=0; i--){
			// This implementation will allow unrestricted
			// mutual access across objects, which is not desirable.
			if(ModelStack.at(i)->symbol_exists(lex))
				return true;
		}
	}
	
	return false;
}


// Return index of stack frame where given symbol is stored
int Environment::getsymbolstack(string symname){
	for(int i=curstack; i>=0; i--){
		Symbol sym = ModelStack.at(i)->getsymbol(symname);
		if(sym.getname() == symname)
			return i;
	}
	return -1;
}


// Fetch and return a symbol with the given name
Symbol Environment::getsymbol(string name){
	int stack_index = getsymbolstack(name);
	if(stack_index >= 0)
		return ModelStack.at(stack_index)->getsymbol(name);
	Symbol sym("", "", Tokens::None);
	return sym;
}

// Modify a symbol on the stack.
void Environment::updatesymbol(Symbol sym){
	int stack_index = getsymbolstack(sym.getname());
	if(stack_index >= 0)
		ModelStack.at(stack_index)->updatesymbol(sym);
}


// Add a model to the stack
void Environment::addmodel(Model mod){
	models.insert(pair<string, Model>(mod.getname(), mod));
	//cout << "Model '" << mod.getname() << "' added. Models: " << models.size() << endl;
}


// Get stack frame for model named 'modname'.
Model* Environment::getmodelstack(string modname){
	for(int i=curstack; i>=0; i--){
		if(ModelStack.at(i)->getname() == modname)
			return ModelStack.at(i);
	}
	return nullptr;
}


// Make sure we do not try to redeclare a symbol
bool Environment::model_exists(string lex){
	if(models.count(lex) > 0)
		return true;
	return false;
}


// Fetch and return a model with the given name
Model Environment::getmodel(string name){
	if(model_exists(name))
		return models.find(name)->second;
	Model mod("");
	return mod;
}


// Modify a model.
void Environment::updatemodel(Model mod){
	models.find(mod.getname())->second = mod;
}


// Return number of first-class models
int Environment::countmodels(){
	return models.size();
}


// Return number of initialized model stack frames
int Environment::countmodelstacks(){
	return ModelStack.size();
}


#endif
