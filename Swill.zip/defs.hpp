﻿#ifndef DEFS_HPP
#define DEFS_HPP

#include <string>
#include <vector>
#include <iostream>

using namespace std;

enum class Tokens{
	/* Null type 		*/
	None,
	
	/* Type specifiers 	*/
	String, Number, Character, Array, Model,
	
	/* Major token categories. */
	Cstring, Mathop, Comment, Assignment, Comparison,
	Declaration, Boolean,
	
	/* Classes of symbol */
	Function, Object_Model, Object, Variable,
	
	/* Single tokens */
	Dot, Newline, Comma, Semicolon, Obracket, Cbracket,
	Obrace, Cbrace, Address_of, Pipe,
	
	/* Keywords */
	Print, Break, Return, Continue, Exec_Stop,
	Decl_Block, Exec_Block, Object_Ctor, Public, 
	Private, While, For, Foreach, If, Else,
	
	/* Assign Ops */
	Assign, Plus_Assign, Minus_Assign, Mult_Assign,
	Div_Assign, Mod_Assign, Increment, Decrement,
	
	/* Mathops */
	Plus, Minus, Times, Divide, Modulo, Power,
	
	/* Relational Operators */
	Greater_Than, Less_Than, Equal_To, Not, Not_Equal,
	Greater_Or_Equal, Less_Or_Equal, And, Or,
	
	/* Boolean */
	True, False
};


// This is used by parser to keep track of tokens encountered
struct History{
	string lexeme = "";
	Tokens token;
	int line_number;	// The line
	int position;		// and character where this token occurs
	
	History(){
		line_number = 1;
		position = 1;
	}
};


struct ActiveModel{
	vector<string> models;
	
	void push(string mod){
		models.push_back(mod);
	}
	
	string pop(){
		string mod = "";
		if(models.size() > 0){
			mod = models.at(models.size()-1);
			models.erase(models.end()-1);
		}
		return mod;
	}
	
	
	string get(){
		if(models.size() > 0){
			return models.at(models.size()-1);
		}
		return "";
	}
	
	
	bool in_model(){
		if(models.size() > 0)
			return true;
		return false;
	}
	
};




struct State{
	int scannerpos;
	History current;
	History previous;
	bool saved;
	
	State(int pos, History cur, History prev) :
		scannerpos{pos},
		current{cur},
		previous{prev},
		saved{true}
	{}
	
	State(): saved{false}{}
};




struct ParserState{
	private:
	vector<State> states;
	
	public:
	ParserState(){}
	
	void push(State state){
		states.push_back(state);
	}
	
	State pop(){
		State st;
		if(states.size() > 0){
			st = states.at(states.size()-1);
			states.erase(states.end()-1);
		}
		return st;
	}
};


// Source file loaded by scanner
struct Source{
	string name;
	string source;
};


// These are defined here to be accessed from anywhere.
// current_line and current_char are used by both scanner
// and parser, while the History instances are used both in
// parser and in utils.
int current_line = 1;
int current_char = 1;
History previous, current, next;
ActiveModel active_models;
ParserState parser_states;
vector<Source> sources;


#endif
