﻿
model Start{
	/*
	string period = test(samp);
	println();
	println(samp.password);		// Access violation
	*/

	/*
	Sample.greet("Programmer", "morning");
	samp;
	println("Default function done.");
	*/

	__decl__
	//Sample samp;
	num number;

	function test(Sample samp){
		string period = samp.greet("Sunnyside");
		return period;
	}
	
	function Default(){
		number = 20021983;
		printNum();
	}
	
	function printNum(num number=2018){
		print("Number is ", Start.number);
	}
}



model Sample{
	
	__decl__
	// Private member declarations
	private
	num password = 20021983;
	string period = "afternoon";

	// Public member declarations
	public
	
	function Default(){
		println("Default function executing...");
	}
	
	function greet(string name; string period="evening"){
		print("Hello ", name, "! Good ", period);
		println();
		println(period, Sample.period);
	}
}



run
