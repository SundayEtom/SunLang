﻿#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>
#include <iostream>
#include "defs.hpp"

using namespace std;

void print_error(string msg){
	cout << "Error: Line " << current.line_number << ":";
	cout << current.position << ": " << msg << endl;
}

#endif
