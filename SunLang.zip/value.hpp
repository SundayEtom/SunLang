﻿#ifndef VALUE_HPP
#define VALUE_HPP

#include <string>
#include <sstream>
#include "defs.hpp"

using namespace std;


class Value{
	private:
	string value;
	Tokens type;
	
	
	public:
	Value(string str, Tokens t){
		value = str;
		type = t;
	}
	
	Value(){	// Default constructor
		value = "";
		type = Tokens::None;
	}
	
	
	string get(){ return value; }
	Tokens gettype(){ return type; }
	void set(string val){ value = val; }
	void settype(Tokens t){ type = t; }
	
	// Convert value to a number
	double tonumber();
};



double Value::tonumber(){
	stringstream ss(value);
	double val;
	ss >> val;
	
	return val;
}







#endif
