﻿#ifndef PARSER_HPP
#define PARSER_HPP

#include "scanner.hpp"
#include "value.hpp"
#include "symbol.hpp"
#include "environment.hpp"
#include "utils.hpp"



class Parser{
	private:
	Scanner sc;
	Symbol latest_symbol;
	Tokens latest_operation;
	bool declare_public;	// true if symbols have public access, false otherwise.
	
	
	public:
	// Constructor: To initialize the scanner and parse the program
	Parser(string text_or_file);
	
	private:
	//Save current token as previous and get a new one.
	bool advance();
	
	// See which token is next, without actually
	// altering current parser state.
	Tokens lookahead();
	
	// Compare current token to the expected one
	bool match(Tokens tok);
	
	// Compare current lexeme to the expected one
	bool match(string lex);
	
	// Print error message and stop the parser. exit() is included in scanner (cstdlib)
	void terminate(string msg){
		print_error(msg);
		exit(EXIT_SUCCESS);
	}
	
	// Simply stop the parser, without error message
	void terminate(){ exit(EXIT_SUCCESS); }
	
	// Check if we're currently executing a model
	bool in_model();
	
	// Check if current lexeme is a type specifier
	bool is_typespec(string lex, Tokens& whichtok);
	
	// Check if current lexeme is a language keyword
	bool is_keyword(string lex);
	
	// Check if current lexeme is a symbol identifier
	bool is_identifier(string lex, bool decl);
	
	// If this is neither a keyword nor a symbol name, return true
	bool is_unknown(string lex, bool decl);
	
	// Is current token the name of a model?
	bool is_model(string lexeme);
	
	// Initialize an instance of a model
	void initialize_object(Symbol sym);
	
	// Do the dirty work for initialize_object()
	void initialize(int end);
	
	// Fetch and return the typespec token for the given lexeme
	Tokens get_typespec_tok(string lexeme);
	
	// Fetch and return the keyword token for the given lexeme
	Tokens get_keyword_tok(string lexeme);
	
	// Determine the specific assignment operation
	Tokens get_assignop_tok(string assignop);
	
	// Get the end of the current block
	int getblockend(bool skip);
	
	// Save current parser state
	void save_parser_state();
	
	// Expression parser
	Value expression();
	
	// Parse a sub-expression called term
	Value term();
	
	
	// Restore parser state, and reset scanner if required.
	void restore_parser_state(bool reset_scanner);
	
	/*
	assert_unknown() checks that a name does not conflict
	with a keyword, type specifier or existing symbol.
	If this conflict is detected, an appropriate error
	message is printed and parsing is terminated.
	*/
	void assert_unknown(string lexeme, string used_for, bool decl);
	
	// Declare a new symbol. 'tok' is the type of this symbol
	string declaration(string class_name, Tokens tok);
	
	// Assign the value of an expression to sym
	void assignment(Symbol& sym);
	
	// Print all comma-separated expressions until a closing bracket is found
	void print(string lexeme);
	
	// Create a new model (or class, like in C++)
	bool class_decl(void);
	
	// Execute the body of a function
	Value execute_function_body(int end);
	
	// Execute object method
	Value function();
	
	// Execute a symbol's default function
	Value execute_default(Symbol& sym);
	
	// Symbol evaluator, to assist factor
	Value evaluate(Symbol& sym);
	
	/* 
	Any expression is a factor.
	In fact, every token is a factor which may or may not
	have a value. If a factor has no value, factor() returns
	an empty string.
	*/
	Value factor();
};



Parser::Parser(string text_or_file):
	sc{Scanner(text_or_file)},
	latest_symbol{Symbol("", "", Tokens::None)},
	declare_public{false}	// By default, all object members are private
{
	advance();
	// Every program must start with a model declaration
	Tokens tok = get_typespec_tok(current.lexeme);
	
	if(tok == Tokens::Object_Model){
		while(tok == Tokens::Object_Model){
			if(!class_decl())	// class_decl() should advance after model declaration
				break;
			tok = get_typespec_tok(current.lexeme);
		}
	}
	else{
		terminate("Model declaration expected but found '"+current.lexeme+"'.");
	}
	
	
	/*
	After model declarations, we start the
	program execution here. Every complete program must have exactly one
	Start model, where program execution starts. If no model
	with name 'Start' is found, then we terminate with an error message.
	*/
	
	Model start = environment.getmodel("Start");
	if(start.getname() == ""){
		terminate("No 'Start' model defined. Program stopped.");
	}
	else{
		sc.setpos(start.getstart());
		advance();
		environment.newstackframe(start.getname());
		active_models.push("Start");
		
		// Initialize the model by executing all declarations within it.
		// That way, we can use a symbol before its actual definition.
		save_parser_state();
		initialize(start.getend());
		restore_parser_state(true);		// Reset scanner
		
		// Search for and execute Start's default function,
		// if it has any.
		save_parser_state();
		sc.setpos(start.getstart());
		// Ssarch for Default function
		bool default_found = false;
		while(sc.getpos() != start.getend()){
			if(match("Default")){
				default_found = true;
				break;
			}
			advance();
		}
		if(default_found){
			function();
		}
		restore_parser_state(true);	
		
		// Now execute the Start model
		while(!match(Tokens::Decl_Block)){
			expression();	// We expect factor() to call advance() before it returns.
		}					// That way, we don't have to call advance() within the loop
		
		environment.popstack();
		active_models.pop();
		terminate();
	}				
}


bool Parser::in_model(){
	return active_models.in_model();
}



void Parser::save_parser_state(){
	State state(sc.getpos(), current, previous);
	parser_states.push(state);
}


void Parser::restore_parser_state(bool reset_scanner=true){
	State state = parser_states.pop();
	if(reset_scanner){
		sc.setpos(state.scannerpos);
		current = state.current;
		previous = state.previous;
	}
}


bool Parser::match(Tokens tok){
	if(current.token == tok)
		return true;
	return false;
}



bool Parser::match(string lex){
	if(current.lexeme == lex)
		return true;
	return false;
}	



bool Parser::is_typespec(string lex, Tokens& whichtok){
	if(typespecs.count(lex) > 0){
		whichtok = typespecs.find(lex)->second;
		return true;
	}
	else if(environment.model_exists(lex)){
		whichtok = Tokens::Object;
		return true;
	}
	
	whichtok = Tokens::None;
	return false;
}


bool Parser::is_keyword(string lex){
	if(keywords.count(lex) > 0)
		return true;
	return false;
}


bool Parser::is_identifier(string lex, bool decl=true){
	return environment.symbol_exists(lex, decl);
}


void Parser::assert_unknown(string lexeme, string used_for, bool decl=true){
	string msg = "";
	Tokens tok;
	
	if(is_typespec(lexeme, tok))
		msg += "Use of a type specifier '"+lexeme+"' as "+used_for+".";
	else if(is_keyword(lexeme))
		msg += "Use of language keyword '"+lexeme+"' as "+used_for+".";
	else if(in_model() && is_identifier(lexeme, decl))
		msg += "Cannot redeclare '"+lexeme+"'.";
			
	if(msg != "") terminate(msg);
}


bool Parser::is_unknown(string lex, bool decl=true){
	Tokens tok;
	if(!is_typespec(lex, tok) && 
		!is_keyword(lex) && 
		!is_identifier(lex, decl) &&
		!is_model(lex)
	)
		return true;
	return false;
}


bool Parser::is_model(string lexeme){
	if(models.count(lexeme) > 0)
		return true;
	return false;
}


Tokens Parser::get_typespec_tok(string lexeme){
	Tokens tok = Tokens::None;
	if(is_typespec(lexeme, tok)){
		return tok;
	}
	return Tokens::None;
}


Tokens Parser::get_keyword_tok(string lexeme){
	if(is_keyword(lexeme)){
		return keywords.find(lexeme)->second;
	}
	return Tokens::None;
}


Tokens Parser::get_assignop_tok(string assignop){
	if(assignops.count(assignop) > 0){
		return assignops.find(assignop)->second;
	}
	return Tokens::None;
}


// We assume the current token is Tokens::Obrace
// If skip is true, the parser continues after the 
// block's end; else parsing continues at the block's
// beginning,which means the block is actually executed.
int Parser::getblockend(bool skip=false){
	if(match(Tokens::Obrace)){
		// Save parser state
		save_parser_state();
		
		int obraces=1, cbraces=0;
		while(obraces != cbraces){
			advance();
			if(match(Tokens::Obrace)) obraces++;
			else if(match(Tokens::Cbrace)) cbraces++;
		}
		int blockend = sc.getpos();
		restore_parser_state(skip);
		
		return blockend;
	}
	return -1;
}


	
bool Parser::advance(){
	previous = current;
	current.token  = sc.scan();
	if(match(Tokens::None)){
		terminate();
	}
	current.lexeme = sc.getlexeme();
	current.line_number = current_line;
	current.position = current_char-current.lexeme.length();
		
	return true;
}


Tokens Parser::lookahead(){
	save_parser_state();
	advance();
	Tokens tok = current.token;
	restore_parser_state();
	return tok;
}


// class_decl() simply creates a new type and adds it to usertypes
bool Parser::class_decl(void){
	advance();
	string model_name = current.lexeme;
	
	if(match(Tokens::Cstring)){
		assert_unknown(model_name, "model object name");
		
		// Now move to model opening brace
		advance();
		
		Model model(model_name);
		model.setstart(sc.getpos());
		model.setend(getblockend(false));	// false means 'skip the block'
		environment.addmodel(model);
	}
	else{
		terminate("Model name must be a character string.");
	}
	return advance();
}


void Parser::initialize_object(Symbol sym){
	/*
	Set up a new stack frame with a copy of the object model; 
	then after declaration, pop this stack
	frame and assign its address to the instance object's symbol stack.
	Next time we want to access this object's members, we'll simply
	install its symbol stack frame on the stack to access its last state.
	*/
	save_parser_state();
	Model mod = environment.getmodel(sym.getclassname());
				
	if(mod.getname() != ""){
		environment.newstackframe(&mod);
		sc.setpos(mod.getstart());
		advance();
		
		initialize(mod.getend());
		
		environment.popstack();
		// Initialize this symbol's stack
		sym.symbol_stack = new Model(sym.getname());
					
		// Assign current model's stack frame to the symbol's symbol stack.
		*sym.symbol_stack = mod;
					
		// Save these changes for future use
		environment.updatesymbol(sym);
		
		// Now execute this symbol's default function,
		// if it has any.
		save_parser_state();
		environment.newstackframe(sym.symbol_stack);
		sc.setpos(sym.symbol_stack->getstart());
		execute_default(sym);
		environment.popstack();
		restore_parser_state(true);
	}
	restore_parser_state();
}



void Parser::initialize(int end){
	// Skip ahead to the declaration section
	while(sc.getpos() != end){
		if(match(Tokens::Decl_Block)){	// We've arrived
			advance();	// Skip the __decl__ token
			break;
		}
		advance();
	}
					
	while(sc.getpos() != end){
		Tokens tok;
		if(is_typespec(current.lexeme, tok)){
			if(tok == Tokens::Object_Model){
				class_decl();
				//advance();
			}
			else declaration(current.lexeme, tok);
		}
		else if(is_keyword(current.lexeme)){
			Tokens tok = get_keyword_tok(current.lexeme);
			if(tok == Tokens::Public) declare_public = true;
			else if(tok == Tokens::Private) declare_public = false;
			advance();
		}
		else advance();
	}
}



string Parser::declaration(string class_name, Tokens tok){
	advance();
	string symname = current.lexeme;
	
	switch(tok){
		case Tokens::Object:{
			assert_unknown(symname, "variable name", true);
			
			Symbol sym(symname, class_name, tok);
			sym.setaccess((declare_public)?"public":"private");
			environment.addsymbol(sym);
			latest_symbol = sym;
			//cout << "'" << symname << "' declared.\n";
			initialize_object(sym);
		}break;
		
		
		case Tokens::Function:{
			// cout << "Declaring function: " << symname << endl;
			assert_unknown(symname, "function name", true);
			
			Symbol sym(symname, class_name, tok);
			sym.symbol_stack = new Model(symname);
			sym.setaccess((declare_public)?"public":"private");
			
			advance();
			if(match(Tokens::Obracket)){
				environment.newstackframe(sym.symbol_stack);
				advance();	// Step into the parameter list
				while(!match(Tokens::Cbracket)){
					Tokens type = get_typespec_tok(current.lexeme);
					if(type == Tokens::None){
						terminate("Unknown parameter type '"+current.lexeme+"'");
					}
					string name = declaration(current.lexeme, type);
					
					// Save this parameter name for later when
					// this function will be called.
					sym.addparam(name);
					
					// The next token may be the terminating Cbracket
					// if current parameter is the last and was assigned a default
					// value obtained by calling expression().
					if(match(Tokens::Cbracket))
						break;
					advance();
					
					// Parameters are separated by commas or semicolons
					if(match(Tokens::Comma) || match(Tokens::Semicolon))
						advance();
				}
				advance();	// Move from Cbracket to function's Obrace
				environment.popstack();
			}
			else{
				terminate("Function must be declared with a parameter list, even if empty");
			}
			sym.symbol_stack->setstart(sc.getpos());
			sym.symbol_stack->setend(getblockend(false));
			
			environment.addsymbol(sym);
			latest_symbol = sym;
		}break;
		
		
		case Tokens::Object_Model:{
			assert_unknown(symname, "object name", true);
			
			cout << "Declaring nested model: '" << symname << "\n";
			class_decl();
			
		}break;
		
		
		default:{
			assert_unknown(symname, "variable name", true);
			
			Symbol sym(symname, class_name, tok);
			sym.setaccess((declare_public)?"public":"private");
			environment.addsymbol(sym);
			latest_symbol = sym;
			
			if(lookahead() == Tokens::Assignment)
				advance();
			if(match(Tokens::Assignment)){
				assignment(sym);
				Symbol s = environment.getsymbol(symname);
				//cout << "assignment(): s.getvalue() yields: " << s.getvalue() << endl;
			}
		}break;
	}
	
	if(match(Tokens::Comma)){			// If the next token is a comma,
		declaration(class_name, tok);	// keep declaring with same type
	}
	else if(match(Tokens::Semicolon)){
		//advance();
	}
	
	latest_operation = Tokens::Declaration;
	return symname;
}


// Print all comma-separated expressions until 
// a closing bracket is found. 'lexeme' tells us which
// print variant to use: print() or println()
void Parser::print(string lexeme){
	advance();
	if(match(Tokens::Obracket)){
		advance();
		int argcount = 0;
		while(!match(Tokens::Cbracket)){
			if(match(Tokens::Comma))
				advance();
			string expr = expression().get();
			argcount++;
			cout << expr;
			if(lexeme == "println")
				cout << endl;
		}
		if(argcount <= 0 && lexeme == "println")
			cout << endl;
	}
	else{
		terminate("Opening bracket (() expected, but found '"+current.lexeme+"'.");
	}
}



// Current token is Tokens::Assignment. We advance()
// once and fetch the expression next to '=' and assign
// to 'sym'.
void Parser::assignment(Symbol& sym){
	string assignop = current.lexeme;
	advance();	//Move past the assignment symbol
	Value value = expression();
	
	switch(get_assignop_tok(assignop)){
		case Tokens::Assign: sym.setvalue(value); break;
		default: break;
	}
	
	environment.updatesymbol(sym);
	latest_operation = Tokens::Assignment;
}



Value Parser::expression(){
	Value val = term();
	
	return val;
}



Value Parser::term(){
	Value val1 = factor();
	
	while(match(Tokens::Mathop)){
		if(match("*")){
			cout << "Multiplication\n";
			Value val2 = factor();
		}
		else if(match("/")){
			cout << "Division.\n";
			Value val2 = factor();
		}
		else if(match("%")){
			cout << "Modulo.\n";
			Value val2 = factor();
		}
		else break;
	}
	
	return val1;
}



// Execute the main body of a function
Value Parser::execute_function_body(int end){
	Value val;
	while(sc.getpos() != end){
		val = expression();
		// 'return' terminates a function before its end.
		// If 'return' is followed by an expression, that
		// expression is evaluated and its value is returned
		// to the caller; else the function returns an empty string.
		// Note that 'return' is not necessary to terminate the
		// function: when it gets to its end, the function will
		// terminate.
		if(match(Tokens::Return)){
			if(lookahead() != Tokens::Semicolon){
				advance();
				val = expression();
			}
			break;
		}
	}
	
	return val;
}



Value Parser::function(){
	Value val;
	Symbol sym = environment.getsymbol(current.lexeme);
	vector<string> params = sym.getparams();	// The formal parameters of this function
	vector<Value> args;		// This will hold its actual parameters
	
	advance();
	if(match(Tokens::Obracket)){
		//cout << "Executing function: " << sym.getname() << endl;
		advance();	// Move into param list
		// Now fetch all the arguments with which this function was called
		// and save their values in args above.
		while(!match(Tokens::Cbracket)){
			if(match(Tokens::Comma))
				advance();
			if(match(Tokens::Cstring)){
				// Fetch the symbol with this name
				Symbol s = environment.getsymbol(current.lexeme);
				Tokens type = s.getclass();	// Obtain its type
				if(type != Tokens::None){
					switch(type){
						case Tokens::Object:{
							// Objects do not have immediate values;
							// so simply save its name and the fact that it is an object.
							Value v(s.getname(), Tokens::Object);
							args.push_back(v);
							// We must advance here because we're fetching this argument manually, 
							// else next argument may not be processed correctly.
							advance();
						}break;
						
						case Tokens::Function:{
							// Todo
						}break;
						
						default:{	// The symbol is a variable of a simple type;
							// so simply evaluate and save its value
							Value v = expression();
							args.push_back(v);
						}break;
					}
				}
				else{
					terminate("Unknown function argument '"+current.lexeme+"'.");
				}
			}
			else{	// This argument is a literal expression
				Value v = expression();
				args.push_back(v);
			}
		}
		/*
		Don't forget that function() was called by factor(). Hereafter, we will
		return to factor(), which will call advance() before it returns. So,
		after fetching the called function's arguments above, there is no need
		to advance(). If we do, we may execute code outside the parameter list,
		which will certainly lead to unwanted behaviour. The next token after
		fetching parameters above is Tokens::Cbracket (i.e. closing bracket). We
		have to allow the scanner to pause there until it is necessary to advance() 
		below or outside function().
		*/
	}
	else{
		terminate("Function must be called with a parameter list, even if empty.");
	}
	
	// If number of actual parameters is less than 
	// or equal to that of formal parameters, do the following:
	// (Note: If actual params are less than formal params,
	// then the excess formal params will retain their default values)
	if(args.size() <= params.size()){
		// Install the function's stack
		environment.newstackframe(sym.symbol_stack);
		
		int i=0;	// Index into argument list
		for(Value v : args){
			if(i >= params.size()){
				terminate("Too many arguments to function '"+sym.getname()+"'.");
			}
			Symbol symbol = environment.getsymbol(params.at(i++));	// Fetch a symbol by name
			//Value v = args.at(i++);
			if(v.gettype() == Tokens::Object){	// If this argument is an object
				Symbol symb = environment.getsymbol(v.get());
				// assign its symbol stack to the corresponding formal parameter
				symbol.symbol_stack = symb.symbol_stack;
			}
			else{
				// Argument is neither an object nor a function.
				symbol.setvalue(v);	// Simply pass its value to this parameter
			}
			environment.updatesymbol(symbol);	// Save this change on the current stack
		}
		
		// Save current state of the parser and reset
		// the scanner to the function's block start.
		save_parser_state();
		sc.setpos(sym.symbol_stack->getstart());
		advance();
		
		// Now execute the function's body
		val = execute_function_body(sym.symbol_stack->getend());
		
		
		// Uninstall the symbol's stack frame
		// and restore the parser's state.
		environment.popstack();
		restore_parser_state(true);
	}
	else{
		// Number of formal parameters disagrees with
		// that of actual parameters. Display an error.
		int psize = params.size();
		int asize = args.size();
		string str1 = (psize > 1)?"parameters":"parameter";
		string str2 = (asize > 1)?"were":"was";
		terminate("'"+sym.getname()+"' takes "+to_string(psize)+" "+str1+", but "+to_string(asize)+" "+str2+" passed.");
	}
	
	return val;
}



// Execute a symbol's default function.
// This function assumes the target symbol's stack
// frame has been installed by the caller. All we do here
// is find out if the symbol (which must be a model instance)
// has a default function. If so, we set up the function's
// execution environment and then execute the function.
Value Parser::execute_default(Symbol& sym){
	Value val;
	if(sym.getclass() == Tokens::Object){	// Symbol must be an object
		sc.setpos(sym.symbol_stack->getstart());
		if(environment.symbol_exists("Default", true)){	// true means search only in current stack frame
			Symbol default_func = environment.getsymbol("Default");
			if(default_func.symbol_stack == nullptr)
				default_func.symbol_stack = new Model("Default");
			
			save_parser_state();
			environment.newstackframe(default_func.symbol_stack);
			sc.setpos(default_func.symbol_stack->getstart());
								
			val = execute_function_body(default_func.symbol_stack->getend());
			
			environment.popstack();
			restore_parser_state(true);
		}
	}
	
	return val;
}




// This assists factor for evaluating symbols,
//especially object members.
Value Parser::evaluate(Symbol& sym){
	Value val;
	
	switch(sym.getclass()){
		case Tokens::Function:{
			val = function();
		}break;
										
		case Tokens::Object:{
			//Todo
		}break;
										
		default:{
			val = sym.getvalueobject();
		}break;
	}
	return val;
}



Value Parser::factor(){
	Value val;
	
	switch(current.token){
		/*
		Is this token a character string? (Note that  character string
		is not a string constant) If it is, determine if it is
		a type specifier, an identifier or a language keyword.
		*/
		case Tokens::Cstring:{
			Tokens tok;
			if(is_typespec(current.lexeme, tok)){
				if(lookahead() != Tokens::Dot){
					declaration(current.lexeme, tok);
				}
				else{
					// Current token is a model, which is a type specifier;
					// but it is followed by Tokens::Dot, indicating member access.
					// We install the model's stack and determine whether the request 
					// is grantable. The request is grantable if the requested member 
					// is accessible from the current scope.
					if(tok == Tokens::Object){
						Model tgtmod = environment.getmodel(current.lexeme);
						advance();		// Advance to the dot
						advance();		// Fetch the member after the dot
						// Get the stack frame for this model
						Model* stack = environment.getmodelstack(tgtmod.getname());
						
						if(stack == nullptr){
							// The model was not initialized through instantiation.
							// So we initiaize it.
							save_parser_state();
							sc.setpos(tgtmod.getstart());
							stack = new Model(tgtmod.getname());
							environment.newstackframe(stack);
							active_models.push(tgtmod.getname());
							//cout << "factor(): Model '" << tgtmod.getname() << "' not previously initialized. Initializing...\n";
							initialize(tgtmod.getend());
							restore_parser_state(true);
						}
						else{
							// Install the stack frame
							environment.newstackframe(stack);
							active_models.push(tgtmod.getname());
						}
						
						if(environment.symbol_exists(current.lexeme, true)){
							// Requested symbol exists. So get it.
							Symbol member = environment.getsymbol(current.lexeme);
							// We are trying to access a member of an external model
							// directly. Such access is only possible if that member
							// was declared as public.
							if((member.getaccess() == "public") || (tgtmod.getname() == active_models.get())){
								val = evaluate(member);
							}
							else{
								terminate("'"+member.getname()+"' in model '"+tgtmod.getname()+"' is private");
							}
						}
						else terminate("'"+tgtmod.getname()+"' has no member named '"+current.lexeme+"'");
							
						environment.popstack();
						active_models.pop();
					}
				}
			}
			else if(is_identifier(current.lexeme, false)){
				Symbol sym = environment.getsymbol(current.lexeme);
				if(sym.getclass() == Tokens::Object){
					// Install this object's stack frame
					environment.newstackframe(sym.symbol_stack);
					active_models.push(current.lexeme);
					
					// We expect a dot here, so advance
					advance();
					if(match(Tokens::Dot)){
						//cout << "Dot found: member access expected\n";
						advance();
						string member = current.lexeme;
						if(environment.symbol_exists(member, false)){
							Symbol symbol = environment.getsymbol(member);
							if(symbol.getaccess() == "private"){
								terminate("'"+symbol.getname()+"' is private to '"+sym.getname()+"'");
							}
							val = evaluate(symbol);
							//cout << sym.getname() << "'s '" << member << "' member requested.\n";
						}
						else{
							terminate(sym.getname()+" has no member called '"+member+"'.");
						}
					}
					else{
						// We're dealing directly with a stand-alone Object.
						// In this case, it works as a function because we
						// simply execute its default function, where there is
						// one. If this object has no default function, no action
						// is taken.
						save_parser_state();
						environment.newstackframe(sym.symbol_stack);
						
						val = execute_default(sym);
						
						environment.popstack();
						restore_parser_state(true);
						// cout << "factor(): '" << sym.getname() << "' is an object of type " << sym.getclassname() << endl;
					}
					environment.popstack();
					active_models.pop();
				}
				else if(sym.getclass() == Tokens::Function){
					val = function();
				}
				else{
					// OK, the symbol is neither an object nor a function.
					// It is most likely an object of a simple type.
					latest_symbol = environment.getsymbol(current.lexeme);
					// We can carry out many operations on this symbol.
					// This is the right place to define such operations;
					// but for now, we simply get its value.
					val = latest_symbol.getvalueobject();
					//cout << "factor(): Value of lone symbol: " << latest_symbol.getvalue() << endl;
				}
			}
			else if(is_keyword(current.lexeme)){
				Tokens token = get_keyword_tok(current.lexeme);
				// A language keyword, like print
				switch(token){
					case Tokens::Print:{
						// Call print(), passing it the lexeme representing the kind
						// of print operation to carry out.
						print(current.lexeme);
					}break;
					
					default: cout << "Unknown keyword: " << current.lexeme << endl; break;
				}
			}
			else{
				terminate("Unknown symbol '"+current.lexeme+"'.");
			}
		}break;
		
		
		// We are assigning to the latest symbol
		case Tokens::Assignment:{
			switch(latest_symbol.getclass()){
				case Tokens::Object:{
					// Todo
				}break;
				
				case Tokens::Function:{
					terminate("You cannot assign to a function.");
				}break;
				
				default: assignment(latest_symbol); break;
			}
		}break;
		
		
		case Tokens::Number:{
			val.settype(Tokens::Number);
			val.set(current.lexeme);
		}break;
		
		
		case Tokens::String:{
			val.settype(Tokens::String);
			val.set(current.lexeme);
		}break;
		
		
		case Tokens::Obracket:{
			advance();	// Step into the bracket-delimited expression
			val = expression();
			if(!match(Tokens::Cbracket)){
				terminate("Closing bracket ()) expected, but found '"+current.lexeme+"'.");
			}
		}break;
		
		
		default: break;
	}
	
	// This call to advance() is important to 
	// avoid an infinit loop in Parser()
	advance();
	return val;
}

#endif
